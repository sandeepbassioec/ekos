import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import knowledgeHubRoutes from "./knowledge-hub.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-ee10ef9d/health", (c) => {
  return c.json({ status: "ok" });
});

// Mount Knowledge Hub routes
app.route("/make-server-ee10ef9d/knowledge-hub", knowledgeHubRoutes);

Deno.serve(app.fetch);