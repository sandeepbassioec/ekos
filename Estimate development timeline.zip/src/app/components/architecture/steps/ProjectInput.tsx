import React, { useState, useEffect } from 'react';
import { FileText, Upload, Inbox } from 'lucide-react';
import { Button } from '../../ui/button';
import { Label } from '../../ui/label';
import { Textarea } from '../../ui/textarea';
import { RadioGroup, RadioGroupItem } from '../../ui/radio-group';
import { Card } from '../../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../ui/select';

interface ProjectInputProps {
  data: any;
  onChange: (data: any) => void;
}

export function ProjectInput({ data, onChange }: ProjectInputProps) {
  const [inputMethod, setInputMethod] = useState<'existing' | 'manual' | 'wbs'>('existing');
  const [existingProjects, setExistingProjects] = useState<any[]>([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [requirements, setRequirements] = useState(data?.requirements || '');

  useEffect(() => {
    // Load existing projects from estimation wizard
    const projects = JSON.parse(localStorage.getItem('projects') || '[]');
    setExistingProjects(projects);
  }, []);

  const handleInputMethodChange = (method: 'existing' | 'manual' | 'wbs') => {
    setInputMethod(method);
    onChange({ ...data, inputMethod: method });
  };

  const handleProjectSelect = (projectId: string) => {
    setSelectedProject(projectId);
    const project = existingProjects.find(p => p.id === projectId);
    
    if (project) {
      // Extract WBS data from project
      const wbsText = extractWBSAsText(project);
      setRequirements(wbsText);
      onChange({
        ...data,
        projectId,
        projectName: project.name,
        requirements: wbsText,
        wbsData: project.wbs,
      });
    }
  };

  const extractWBSAsText = (project: any) => {
    // Convert WBS structure to readable text format
    let text = `Project: ${project.name}\n\n`;
    text += `Description: ${project.description || 'N/A'}\n\n`;
    text += `Features & Modules:\n\n`;

    // Assuming project has modules/features array
    if (project.modules) {
      project.modules.forEach((module: any) => {
        text += `Module: ${module.name}\n`;
        text += `Description: ${module.description || ''}\n`;
        
        if (module.screens) {
          text += `Screens:\n`;
          module.screens.forEach((screen: any) => {
            text += `  - ${screen.name}: ${screen.description || ''}\n`;
            if (screen.components) {
              screen.components.forEach((comp: any) => {
                text += `    • ${comp.name}\n`;
              });
            }
          });
        }
        text += `\n`;
      });
    }

    return text;
  };

  const handleRequirementsChange = (value: string) => {
    setRequirements(value);
    onChange({
      ...data,
      requirements: value,
      inputMethod,
    });
  };

  return (
    <div className="space-y-6">
      {/* Input Method Selection */}
      <div>
        <Label className="text-base mb-3 block">Select Input Method</Label>
        <RadioGroup value={inputMethod} onValueChange={handleInputMethodChange as any}>
          <div className="grid grid-cols-3 gap-4">
            <Card
              className={`p-4 cursor-pointer transition-all ${
                inputMethod === 'existing'
                  ? 'border-primary border-2 bg-primary/5'
                  : 'hover:border-primary/50'
              }`}
              onClick={() => handleInputMethodChange('existing')}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="existing" id="existing" />
                <Label htmlFor="existing" className="cursor-pointer flex-1">
                  <div className="flex items-center gap-2">
                    <Inbox className="w-5 h-5" />
                    <div>
                      <p className="font-semibold">Existing Project</p>
                      <p className="text-xs text-muted-foreground">
                        Import from Estimation Wizard
                      </p>
                    </div>
                  </div>
                </Label>
              </div>
            </Card>

            <Card
              className={`p-4 cursor-pointer transition-all ${
                inputMethod === 'wbs'
                  ? 'border-primary border-2 bg-primary/5'
                  : 'hover:border-primary/50'
              }`}
              onClick={() => handleInputMethodChange('wbs')}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="wbs" id="wbs" />
                <Label htmlFor="wbs" className="cursor-pointer flex-1">
                  <div className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    <div>
                      <p className="font-semibold">Upload WBS</p>
                      <p className="text-xs text-muted-foreground">
                        Import Excel/CSV WBS
                      </p>
                    </div>
                  </div>
                </Label>
              </div>
            </Card>

            <Card
              className={`p-4 cursor-pointer transition-all ${
                inputMethod === 'manual'
                  ? 'border-primary border-2 bg-primary/5'
                  : 'hover:border-primary/50'
              }`}
              onClick={() => handleInputMethodChange('manual')}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="manual" id="manual" />
                <Label htmlFor="manual" className="cursor-pointer flex-1">
                  <div className="flex items-center gap-2">
                    <Upload className="w-5 h-5" />
                    <div>
                      <p className="font-semibold">Manual Input</p>
                      <p className="text-xs text-muted-foreground">
                        Type or paste requirements
                      </p>
                    </div>
                  </div>
                </Label>
              </div>
            </Card>
          </div>
        </RadioGroup>
      </div>

      {/* Conditional Content Based on Selection */}
      {inputMethod === 'existing' && (
        <div>
          <Label htmlFor="projectSelect">Select Project</Label>
          <Select value={selectedProject} onValueChange={handleProjectSelect}>
            <SelectTrigger id="projectSelect">
              <SelectValue placeholder="Choose a project from estimation wizard" />
            </SelectTrigger>
            <SelectContent>
              {existingProjects.length === 0 ? (
                <SelectItem value="none" disabled>
                  No projects found
                </SelectItem>
              ) : (
                existingProjects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name} - {project.method || 'N/A'}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          {existingProjects.length === 0 && (
            <p className="text-sm text-muted-foreground mt-2">
              💡 Tip: Create a project in the Estimation Wizard first
            </p>
          )}
        </div>
      )}

      {inputMethod === 'wbs' && (
        <div className="border-2 border-dashed rounded-lg p-8 text-center">
          <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <h3 className="font-semibold mb-2">Upload WBS File</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Drag and drop your Excel or CSV file here
          </p>
          <Button variant="outline">
            <Upload className="w-4 h-4 mr-2" />
            Choose File
          </Button>
          <p className="text-xs text-muted-foreground mt-4">
            Supported formats: .xlsx, .xls, .csv
          </p>
        </div>
      )}

      {/* Requirements Text Area (shown for all methods) */}
      <div>
        <Label htmlFor="requirements">
          {inputMethod === 'existing'
            ? 'Extracted Requirements (Editable)'
            : 'Requirements Document'}
        </Label>
        <Textarea
          id="requirements"
          value={requirements}
          onChange={(e) => handleRequirementsChange(e.target.value)}
          placeholder={`Enter or paste your requirements here. Example:

Project: E-Commerce Platform

Modules:
1. User Management
   - User Registration (email, password, profile)
   - User Login (email/password, OAuth)
   - Profile Management (update details, change password)
   - Password Recovery

2. Product Catalog
   - Product Listing (search, filter, sort)
   - Product Details (images, description, price, reviews)
   - Category Management
   - Inventory Management

3. Shopping Cart
   - Add to Cart
   - Update Quantity
   - Remove Items
   - Save for Later

4. Checkout & Payment
   - Shipping Address
   - Payment Gateway Integration (Stripe, PayPal)
   - Order Confirmation
   - Invoice Generation

5. Order Management
   - Order History
   - Order Tracking
   - Order Cancellation
   - Return/Refund Process

6. Admin Panel
   - Dashboard (sales, orders, users stats)
   - Product Management (CRUD)
   - User Management
   - Order Management
   - Reports & Analytics`}
          className="min-h-[300px] font-mono text-sm"
        />
        <p className="text-xs text-muted-foreground mt-2">
          💡 Be specific about features, user types, and functionality. This will help generate accurate architecture.
        </p>
      </div>

      {/* Quick Tips */}
      <Card className="bg-blue-50 border-blue-200">
        <div className="p-4">
          <h4 className="font-semibold text-blue-900 mb-2">📝 Tips for Better Results:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>✓ List all modules and their features</li>
            <li>✓ Mention user types (Admin, User, Guest, etc.)</li>
            <li>✓ Include database entities (User, Product, Order, etc.)</li>
            <li>✓ Describe key workflows and integrations</li>
            <li>✓ Mention third-party APIs if any (Payment, Email, SMS)</li>
          </ul>
        </div>
      </Card>
    </div>
  );
}
