import React, { useState } from 'react';
import { Brain, FileText, Video, Mail, MessageSquare, Sparkles, Download, Trash2, Check, Loader2, AlertCircle, AlertTriangle } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Checkbox } from '../ui/checkbox';
import { Alert, AlertDescription } from '../ui/alert';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '../ui/dialog';
import { useKnowledgeHubStore } from '../../store/knowledgeHubStore';
import type { AIRequirement, RequirementPriority, RequirementCategory } from '../../types/knowledge-hub';
import { toast } from 'sonner';

interface AIRequirementsTabProps {
  roadmapItemId: string;
  requirements: AIRequirement[];
}

export function AIRequirementsTab({ roadmapItemId, requirements }: AIRequirementsTabProps) {
  const { analyzeAllSources, deleteAIRequirement, isAnalyzing, currentHub } = useKnowledgeHubStore();
  const [selectedRequirements, setSelectedRequirements] = useState<Set<string>>(new Set());
  const [showSuccess, setShowSuccess] = useState(false);
  const [showNoDocDialog, setShowNoDocDialog] = useState(false);

  const hasDocuments = (currentHub?.stats.totalDocuments ?? 0) > 0;
  const totalMeetings = currentHub?.stats.totalMeetings ?? 0;
  const totalEmails = currentHub?.stats.totalEmails ?? 0;
  const totalChats = currentHub?.stats.totalChats ?? 0;
  const secondarySourceCount = totalMeetings + totalEmails + totalChats;
  const totalSources = (currentHub?.stats.totalDocuments ?? 0) + secondarySourceCount;
  const hasAnySources = totalSources > 0;

  const runAnalysis = async (noDocumentMode = false) => {
    setShowSuccess(false);
    setShowNoDocDialog(false);
    const success = await analyzeAllSources(roadmapItemId, noDocumentMode);
    if (success) {
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 5000);
    }
  };

  const handleAnalyzeClick = () => {
    if (!hasDocuments && secondarySourceCount > 0) {
      // No document — ask user for permission first
      setShowNoDocDialog(true);
      return;
    }
    runAnalysis(false);
  };

  const handleDelete = async (requirementId: string) => {
    await deleteAIRequirement(requirementId);
  };

  const toggleRequirement = (requirementId: string) => {
    const newSelected = new Set(selectedRequirements);
    if (newSelected.has(requirementId)) {
      newSelected.delete(requirementId);
    } else {
      newSelected.add(requirementId);
    }
    setSelectedRequirements(newSelected);
  };

  const toggleAll = () => {
    if (selectedRequirements.size === requirements.length) {
      setSelectedRequirements(new Set());
    } else {
      setSelectedRequirements(new Set(requirements.map(r => r.id)));
    }
  };

  const handleExportToRequirements = () => {
    const selected = requirements.filter(r => selectedRequirements.has(r.id));
    const mappedRequirements = selected.map(aiReq => ({
      aiRequirementId: aiReq.id,
      suggestedTitle: aiReq.requirement.substring(0, 100),
      suggestedDescription: aiReq.requirement,
      suggestedType: mapCategoryToRequirementType(aiReq.category),
      suggestedPriority: mapPriorityToRequirementPriority(aiReq.priority),
      source: aiReq.source,
      sourceType: aiReq.sourceType,
      sourceId: aiReq.sourceId,
      confidence: aiReq.confidence,
      category: aiReq.category,
    }));
    localStorage.setItem('importedAIRequirements', JSON.stringify(mappedRequirements));
    localStorage.setItem('aiRequirementsImportTimestamp', Date.now().toString());
    toast.success(`${selected.length} requirements ready to import`);
  };

  const mapCategoryToRequirementType = (category?: RequirementCategory): string => {
    switch (category) {
      case 'Functional': return 'feature_change';
      case 'Non-Functional': return 'performance';
      case 'Security': return 'security';
      case 'Performance': return 'performance';
      case 'Usability': return 'ui_ux_change';
      default: return 'feature_change';
    }
  };

  const mapPriorityToRequirementPriority = (priority?: RequirementPriority): string => {
    switch (priority) {
      case 'High': return 'high';
      case 'Medium': return 'medium';
      case 'Low': return 'low';
      default: return 'medium';
    }
  };

  const getSourceIcon = (sourceType: string) => {
    switch (sourceType) {
      case 'Document': return <FileText className="w-4 h-4" />;
      case 'Meeting': return <Video className="w-4 h-4" />;
      case 'Email': return <Mail className="w-4 h-4" />;
      case 'Chat': return <MessageSquare className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority?: RequirementPriority) => {
    switch (priority) {
      case 'High': return 'bg-red-100 text-red-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryColor = (category?: RequirementCategory) => {
    switch (category) {
      case 'Functional': return 'bg-blue-100 text-blue-800';
      case 'Non-Functional': return 'bg-purple-100 text-purple-800';
      case 'Security': return 'bg-red-100 text-red-800';
      case 'Performance': return 'bg-green-100 text-green-800';
      case 'Usability': return 'bg-cyan-100 text-cyan-800';
      case 'Scalability': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Describe what will happen when Analyze is clicked
  const analyzeButtonLabel = () => {
    if (isAnalyzing) return null;
    if (requirements.length > 0) {
      if (hasDocuments && secondarySourceCount > 0) return 'Re-analyze & Refine';
      return 'Regenerate Requirements';
    }
    if (hasDocuments && secondarySourceCount > 0) return 'Analyze & Refine';
    return 'Analyze All Sources';
  };

  return (
    <div className="space-y-4">

      {/* No-document confirmation dialog */}
      <Dialog open={showNoDocDialog} onOpenChange={setShowNoDocDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              No Requirements Document Found
            </DialogTitle>
            <DialogDescription asChild>
              <div className="space-y-3 pt-1">
                <p className="text-sm text-muted-foreground">
                  You have uploaded{' '}
                  {[
                    totalMeetings > 0 && `${totalMeetings} meeting${totalMeetings > 1 ? 's' : ''}`,
                    totalEmails > 0 && `${totalEmails} email${totalEmails > 1 ? 's' : ''}`,
                    totalChats > 0 && `${totalChats} chat${totalChats > 1 ? 's' : ''}`,
                  ].filter(Boolean).join(', ')}{' '}
                  but <strong>no requirements document</strong> yet.
                </p>
                <p className="text-sm text-muted-foreground">
                  For best results, upload a BRD / requirements document first so the AI can use it as a baseline and refine it using your meetings, emails, and chats.
                </p>
                <p className="text-sm font-medium">
                  Would you like to analyze all sources together and generate requirements from scratch?
                </p>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2 justify-end pt-2">
            <Button variant="outline" onClick={() => setShowNoDocDialog(false)}>
              Cancel — I'll upload a document first
            </Button>
            <Button onClick={() => runAnalysis(true)}>
              <Sparkles className="w-4 h-4 mr-2" />
              Yes, Analyze All Together
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="flex justify-between items-start gap-4">
        <div>
          <h3 className="text-lg font-semibold">AI-Derived Requirements</h3>
          <p className="text-sm text-muted-foreground">
            {hasDocuments && secondarySourceCount > 0
              ? 'Documents analyzed first as baseline — meetings, emails & chats refine the requirements'
              : hasDocuments
              ? 'Requirements extracted from documents using the Requirements Analyst prompt'
              : 'All sources analyzed together to generate requirements'}
          </p>
        </div>
        <div className="flex gap-2">
          {requirements.length > 0 && selectedRequirements.size > 0 && (
            <Button onClick={handleExportToRequirements} variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export {selectedRequirements.size} to Requirements
            </Button>
          )}
          <Button onClick={handleAnalyzeClick} disabled={isAnalyzing || !hasAnySources} data-analyze-btn>
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                {hasDocuments && secondarySourceCount > 0 ? 'Analyzing & Refining...' : 'Analyzing...'}
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                {analyzeButtonLabel()}
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Success */}
      {showSuccess && (
        <Alert className="border-green-200 bg-green-50">
          <Check className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">
            Successfully analyzed {totalSources} source{totalSources !== 1 ? 's' : ''} and extracted {requirements.length} requirement{requirements.length !== 1 ? 's' : ''}!
          </AlertDescription>
        </Alert>
      )}

      {/* No sources warning */}
      {!hasAnySources && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Add documents, meetings, emails, or chats first to enable AI requirement extraction.
          </AlertDescription>
        </Alert>
      )}

      {/* Analysis mode info banner */}
      {hasAnySources && hasDocuments && secondarySourceCount > 0 && (
        <Alert className="border-blue-200 bg-blue-50">
          <Brain className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800 text-sm">
            <strong>Two-phase analysis:</strong> Documents → baseline requirements.
            Then meetings, emails & chats refine gaps, confusions and suggestions against that baseline.
          </AlertDescription>
        </Alert>
      )}

      {/* Sources Summary */}
      {hasAnySources && (
        <div className="grid grid-cols-4 gap-3">
          {[
            { icon: <FileText className="w-5 h-5 text-blue-600" />, bg: 'bg-blue-100', count: currentHub?.stats.totalDocuments ?? 0, label: 'Documents', note: 'Baseline' },
            { icon: <Video className="w-5 h-5 text-purple-600" />, bg: 'bg-purple-100', count: totalMeetings, label: 'Meetings', note: 'Refines' },
            { icon: <Mail className="w-5 h-5 text-green-600" />, bg: 'bg-green-100', count: totalEmails, label: 'Emails', note: 'Refines' },
            { icon: <MessageSquare className="w-5 h-5 text-orange-600" />, bg: 'bg-orange-100', count: totalChats, label: 'Chats', note: 'Refines' },
          ].map(({ icon, bg, count, label, note }) => (
            <Card key={label} className="border-2">
              <CardContent className="p-4 flex items-center gap-3">
                <div className={`p-2 ${bg} rounded-lg`}>{icon}</div>
                <div>
                  <div className="text-2xl font-bold">{count}</div>
                  <div className="text-xs text-muted-foreground">{label}</div>
                  {hasDocuments && secondarySourceCount > 0 && (
                    <div className="text-xs text-muted-foreground/60 italic">{note}</div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Requirements List */}
      {requirements.length > 0 ? (
        <>
          <div className="flex items-center gap-3 px-4 py-3 bg-muted/50 rounded-lg">
            <Checkbox
              checked={selectedRequirements.size === requirements.length}
              onCheckedChange={toggleAll}
            />
            <span className="text-sm font-medium">
              {selectedRequirements.size > 0
                ? `${selectedRequirements.size} of ${requirements.length} selected`
                : `Select all ${requirements.length} requirements`}
            </span>
          </div>

          <div className="grid gap-3">
            {requirements.map((req) => (
              <Card
                key={req.id}
                className={`hover:shadow-md transition-shadow cursor-pointer ${selectedRequirements.has(req.id) ? 'ring-2 ring-primary' : ''}`}
                onClick={() => toggleRequirement(req.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Checkbox
                      checked={selectedRequirements.has(req.id)}
                      onCheckedChange={() => toggleRequirement(req.id)}
                      onClick={(e) => e.stopPropagation()}
                    />
                    <div className="p-2 bg-primary/10 rounded-lg">
                      {getSourceIcon(req.sourceType)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <p className="text-sm font-medium leading-relaxed">{req.requirement}</p>
                        <div className="flex items-center gap-2">
                          {req.confidence && (
                            <Badge variant="outline" className="text-xs whitespace-nowrap">
                              {Math.round(req.confidence * 100)}% confident
                            </Badge>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => { e.stopPropagation(); handleDelete(req.id); }}
                            className="h-8 w-8 p-0"
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          {getSourceIcon(req.sourceType)}
                          <span>{req.source}</span>
                        </div>
                        {req.category && (
                          <Badge className={`text-xs ${getCategoryColor(req.category)}`}>
                            {req.category}
                          </Badge>
                        )}
                        {req.priority && (
                          <Badge className={`text-xs ${getPriorityColor(req.priority)}`}>
                            {req.priority} Priority
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      ) : hasAnySources ? (
        <Card className="border-2 border-dashed border-primary/30 bg-primary/5">
          <CardContent className="py-12 text-center">
            <Brain className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h3 className="text-lg font-semibold mb-2">Ready to Extract Requirements!</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              {hasDocuments && secondarySourceCount > 0
                ? `Documents will be analyzed first to build the baseline. Then ${secondarySourceCount} secondary source${secondarySourceCount > 1 ? 's' : ''} will refine gaps, confusions and suggestions.`
                : hasDocuments
                ? `${currentHub?.stats.totalDocuments} document${(currentHub?.stats.totalDocuments ?? 0) > 1 ? 's' : ''} ready for deep requirements analysis.`
                : `${secondarySourceCount} source${secondarySourceCount > 1 ? 's' : ''} ready. No document baseline — you will be asked to confirm before analysis.`}
            </p>
            <div className="space-y-2 text-sm text-left max-w-xl mx-auto">
              <div className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span className="text-muted-foreground">Documents analyzed with Principal Requirements Analyst prompt (BABOK v3 / IEEE 830)</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span className="text-muted-foreground">Meetings, emails & chats refine the baseline — extracting decisions, gaps and scope changes</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-primary mt-0.5">✓</span>
                <span className="text-muted-foreground">Assigns priority, category, and confidence scores automatically</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
