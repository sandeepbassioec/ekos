import React, { useState } from 'react';
import { Lightbulb, Plus, Trash2, ThumbsUp, ThumbsDown, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '../ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '../ui/select';
import { db } from '../../lib/db';
import { toast } from 'sonner';
import type { Suggestion } from '../../lib/db/types';

interface SuggestionsTabProps {
  roadmapItemId: string;
  suggestions: Suggestion[];
  onRefresh: () => void;
}

const typeColors: Record<string, string> = {
  Enhancement: 'bg-blue-100 text-blue-800',
  Alternative: 'bg-purple-100 text-purple-800',
  'Best Practice': 'bg-green-100 text-green-800',
  'Risk Mitigation': 'bg-orange-100 text-orange-800',
};

const statusColors: Record<string, string> = {
  Pending: 'bg-gray-100 text-gray-700',
  Accepted: 'bg-green-100 text-green-800',
  Rejected: 'bg-red-100 text-red-800',
  Implemented: 'bg-blue-100 text-blue-800',
};

export function SuggestionsTab({ roadmapItemId, suggestions, onRefresh }: SuggestionsTabProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<Suggestion['type']>('Enhancement');
  const [impact, setImpact] = useState('');
  const [effort, setEffort] = useState('');

  const handleCreate = async () => {
    if (!title || !description) return;
    setIsSubmitting(true);
    try {
      await db.suggestions.create({
        roadmapItemId,
        title,
        description,
        type,
        status: 'Pending',
        generatedBy: 'Manual',
        impact: impact || undefined,
        effort: effort || undefined,
      });
      toast.success('Suggestion added');
      setTitle(''); setDescription(''); setImpact(''); setEffort(''); setType('Enhancement');
      setIsDialogOpen(false);
      onRefresh();
    } catch {
      toast.error('Failed to add suggestion');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleStatusChange = async (suggestion: Suggestion, status: Suggestion['status']) => {
    try {
      await db.suggestions.update(suggestion.id, { status });
      toast.success(`Marked as ${status}`);
      onRefresh();
    } catch {
      toast.error('Failed to update');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await db.suggestions.delete(id);
      toast.success('Deleted');
      onRefresh();
    } catch {
      toast.error('Failed to delete');
    }
  };

  const pendingCount = suggestions.filter(s => s.status === 'Pending').length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Lightbulb className="w-5 h-5 text-yellow-500" />
          <div>
            <h3 className="font-semibold">Suggestions & Recommendations</h3>
            <p className="text-xs text-muted-foreground">
              {suggestions.length} total · {pendingCount} pending review
            </p>
          </div>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="w-4 h-4 mr-2" />Add Suggestion</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Add Suggestion</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1">
                <Label>Title *</Label>
                <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Use OAuth2 for authentication" />
              </div>
              <div className="space-y-1">
                <Label>Description *</Label>
                <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="Detailed explanation of the suggestion..." />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label>Type</Label>
                  <Select value={type} onValueChange={v => setType(v as Suggestion['type'])}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['Enhancement', 'Alternative', 'Best Practice', 'Risk Mitigation'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <Label>Effort</Label>
                  <Input value={effort} onChange={e => setEffort(e.target.value)} placeholder="e.g. Low, 2 days" />
                </div>
              </div>
              <div className="space-y-1">
                <Label>Impact</Label>
                <Input value={impact} onChange={e => setImpact(e.target.value)} placeholder="e.g. Reduces security risk significantly" />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleCreate} disabled={!title || !description || isSubmitting}>
                  {isSubmitting ? 'Adding...' : 'Add'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {suggestions.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <Lightbulb className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No suggestions yet</p>
            <p className="text-sm mt-1">Run AI analysis or add manually</p>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {suggestions.map(s => (
          <Card key={s.id}>
            <CardContent className="pt-4 pb-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{s.title}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${typeColors[s.type]}`}>{s.type}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[s.status]}`}>{s.status}</span>
                    {s.generatedBy === 'AI' && <Badge variant="secondary" className="text-xs">AI</Badge>}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{s.description}</p>
                  {(s.impact || s.effort) && (
                    <div className="flex gap-3 mt-1">
                      {s.impact && <span className="text-xs text-muted-foreground">Impact: {s.impact}</span>}
                      {s.effort && <span className="text-xs text-muted-foreground">Effort: {s.effort}</span>}
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {s.status === 'Pending' && (
                    <>
                      <Button size="sm" variant="outline" className="h-7 text-xs text-green-700 border-green-300" onClick={() => handleStatusChange(s, 'Accepted')}>
                        <ThumbsUp className="w-3 h-3 mr-1" />Accept
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 text-xs text-red-700 border-red-300" onClick={() => handleStatusChange(s, 'Rejected')}>
                        <ThumbsDown className="w-3 h-3 mr-1" />Reject
                      </Button>
                    </>
                  )}
                  {s.status === 'Accepted' && (
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handleStatusChange(s, 'Implemented')}>
                      Mark Implemented
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => handleDelete(s.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
