import React, { useState } from 'react';
import { AlertTriangle, Plus, Trash2, CheckCircle2, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '../ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '../ui/select';
import { db } from '../../lib/db';
import { toast } from 'sonner';
import type { Gap } from '../../lib/db/types';

interface GapsTabProps {
  roadmapItemId: string;
  gaps: Gap[];
  onRefresh: () => void;
}

const severityColors: Record<string, string> = {
  Critical: 'bg-red-100 text-red-800 border-red-200',
  High: 'bg-orange-100 text-orange-800 border-orange-200',
  Medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  Low: 'bg-green-100 text-green-800 border-green-200',
};

const statusColors: Record<string, string> = {
  Open: 'bg-blue-100 text-blue-800',
  'In Progress': 'bg-purple-100 text-purple-800',
  Resolved: 'bg-green-100 text-green-800',
  Closed: 'bg-gray-100 text-gray-800',
};

export function GapsTab({ roadmapItemId, gaps, onRefresh }: GapsTabProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolution, setResolution] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<Gap['severity']>('Medium');
  const [suggestions, setSuggestions] = useState('');

  const handleCreate = async () => {
    if (!title || !description) return;
    setIsSubmitting(true);
    try {
      await db.gaps.create({
        roadmapItemId,
        title,
        description,
        severity,
        status: 'Open',
        sourceType: 'Manual',
        suggestions: suggestions.split('\n').map(s => s.trim()).filter(Boolean),
      });
      toast.success('Gap added');
      setTitle(''); setDescription(''); setSuggestions(''); setSeverity('Medium');
      setIsDialogOpen(false);
      onRefresh();
    } catch {
      toast.error('Failed to add gap');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResolve = async (gap: Gap) => {
    if (!resolution.trim()) return;
    setIsSubmitting(true);
    try {
      await db.gaps.update(gap.id, { status: 'Resolved', resolution });
      toast.success('Gap resolved');
      setResolvingId(null);
      setResolution('');
      onRefresh();
    } catch {
      toast.error('Failed to resolve gap');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await db.gaps.delete(id);
      toast.success('Gap deleted');
      onRefresh();
    } catch {
      toast.error('Failed to delete gap');
    }
  };

  const openCount = gaps.filter(g => g.status === 'Open').length;
  const criticalCount = gaps.filter(g => g.severity === 'Critical' || g.severity === 'High').length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-orange-500" />
          <div>
            <h3 className="font-semibold">Gap Analysis</h3>
            <p className="text-xs text-muted-foreground">
              {gaps.length} total · {openCount} open · {criticalCount} critical/high
            </p>
          </div>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Gap
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Add Gap</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1">
                <Label>Title *</Label>
                <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Missing API authentication specs" />
              </div>
              <div className="space-y-1">
                <Label>Description *</Label>
                <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="Describe what is missing or incomplete..." />
              </div>
              <div className="space-y-1">
                <Label>Severity</Label>
                <Select value={severity} onValueChange={v => setSeverity(v as Gap['severity'])}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['Critical', 'High', 'Medium', 'Low'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label>Suggestions (one per line)</Label>
                <Textarea value={suggestions} onChange={e => setSuggestions(e.target.value)} rows={3} placeholder="Suggested ways to address this gap..." />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleCreate} disabled={!title || !description || isSubmitting}>
                  {isSubmitting ? 'Adding...' : 'Add Gap'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Empty State */}
      {gaps.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <AlertTriangle className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No gaps identified yet</p>
            <p className="text-sm mt-1">Run AI analysis or add gaps manually</p>
          </CardContent>
        </Card>
      )}

      {/* Gap Cards */}
      <div className="space-y-3">
        {gaps.map(gap => (
          <Card key={gap.id} className={`border-l-4 ${gap.severity === 'Critical' ? 'border-l-red-500' : gap.severity === 'High' ? 'border-l-orange-500' : gap.severity === 'Medium' ? 'border-l-yellow-500' : 'border-l-green-500'}`}>
            <CardContent className="pt-4 pb-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{gap.title}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium border ${severityColors[gap.severity]}`}>{gap.severity}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[gap.status]}`}>{gap.status}</span>
                    {gap.sourceType === 'AI' && <Badge variant="secondary" className="text-xs">AI</Badge>}
                  </div>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{gap.description}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {gap.status === 'Open' && (
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => { setResolvingId(gap.id); setResolution(''); }}>
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Resolve
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setExpandedId(expandedId === gap.id ? null : gap.id)}>
                    {expandedId === gap.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => handleDelete(gap.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>

              {/* Expanded */}
              {expandedId === gap.id && (
                <div className="mt-3 pt-3 border-t space-y-2">
                  {gap.suggestions && gap.suggestions.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Suggestions</p>
                      <ul className="space-y-1">
                        {gap.suggestions.map((s, i) => (
                          <li key={i} className="text-sm flex items-start gap-2">
                            <span className="text-primary mt-0.5">•</span>
                            <span>{s}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {gap.resolution && (
                    <div className="bg-green-50 rounded p-2">
                      <p className="text-xs font-medium text-green-700 mb-1">Resolution</p>
                      <p className="text-sm text-green-800">{gap.resolution}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Resolve inline */}
              {resolvingId === gap.id && (
                <div className="mt-3 pt-3 border-t space-y-2">
                  <Label className="text-xs">Resolution / Answer</Label>
                  <Textarea value={resolution} onChange={e => setResolution(e.target.value)} rows={2} placeholder="How was this gap addressed?" />
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" size="sm" onClick={() => setResolvingId(null)}>Cancel</Button>
                    <Button size="sm" onClick={() => handleResolve(gap)} disabled={!resolution.trim() || isSubmitting}>
                      {isSubmitting ? 'Saving...' : 'Mark Resolved'}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
