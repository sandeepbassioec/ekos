import React, { useState } from 'react';
import { HelpCircle, Plus, Trash2, CheckCircle2, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent } from '../ui/card';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '../ui/dialog';
import { db } from '../../lib/db';
import { toast } from 'sonner';
import type { Confusion } from '../../lib/db/types';

interface ConfusionsTabProps {
  roadmapItemId: string;
  confusions: Confusion[];
  onRefresh: () => void;
}

const statusColors: Record<string, string> = {
  Open: 'bg-blue-100 text-blue-800',
  Clarified: 'bg-yellow-100 text-yellow-800',
  Resolved: 'bg-green-100 text-green-800',
};

export function ConfusionsTab({ roadmapItemId, confusions, onRefresh }: ConfusionsTabProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [clarifyingId, setClarifyingId] = useState<string | null>(null);
  const [clarification, setClarification] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [question, setQuestion] = useState('');
  const [context, setContext] = useState('');

  const handleCreate = async () => {
    if (!question || !context) return;
    setIsSubmitting(true);
    try {
      await db.confusions.create({
        roadmapItemId,
        question,
        context,
        sources: [],
        status: 'Open',
      });
      toast.success('Confusion added');
      setQuestion(''); setContext('');
      setIsDialogOpen(false);
      onRefresh();
    } catch {
      toast.error('Failed to add confusion');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClarify = async (confusion: Confusion) => {
    if (!clarification.trim()) return;
    setIsSubmitting(true);
    try {
      await db.confusions.update(confusion.id, { status: 'Resolved', clarification });
      toast.success('Confusion resolved');
      setClarifyingId(null);
      setClarification('');
      onRefresh();
    } catch {
      toast.error('Failed to update confusion');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await db.confusions.delete(id);
      toast.success('Deleted');
      onRefresh();
    } catch {
      toast.error('Failed to delete');
    }
  };

  const openCount = confusions.filter(c => c.status === 'Open').length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <HelpCircle className="w-5 h-5 text-blue-500" />
          <div>
            <h3 className="font-semibold">Confusions & Ambiguities</h3>
            <p className="text-xs text-muted-foreground">
              {confusions.length} total · {openCount} open
            </p>
          </div>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm"><Plus className="w-4 h-4 mr-2" />Add Confusion</Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Add Confusion / Ambiguity</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="space-y-1">
                <Label>Question / Ambiguity *</Label>
                <Input value={question} onChange={e => setQuestion(e.target.value)} placeholder="e.g. Is real-time sync required for all users?" />
              </div>
              <div className="space-y-1">
                <Label>Context *</Label>
                <Textarea value={context} onChange={e => setContext(e.target.value)} rows={3} placeholder="Where did this confusion arise? Which document or statement is unclear?" />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleCreate} disabled={!question || !context || isSubmitting}>
                  {isSubmitting ? 'Adding...' : 'Add'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {confusions.length === 0 && (
        <Card>
          <CardContent className="py-16 text-center text-muted-foreground">
            <HelpCircle className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="font-medium">No confusions identified</p>
            <p className="text-sm mt-1">Run AI analysis or add manually</p>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {confusions.map(confusion => (
          <Card key={confusion.id} className="border-l-4 border-l-blue-400">
            <CardContent className="pt-4 pb-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{confusion.question}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[confusion.status]}`}>{confusion.status}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{confusion.context}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {confusion.status === 'Open' && (
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => { setClarifyingId(confusion.id); setClarification(''); }}>
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Clarify
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => setExpandedId(expandedId === confusion.id ? null : confusion.id)}>
                    {expandedId === confusion.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={() => handleDelete(confusion.id)}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>

              {expandedId === confusion.id && confusion.clarification && (
                <div className="mt-3 pt-3 border-t">
                  <div className="bg-green-50 rounded p-2">
                    <p className="text-xs font-medium text-green-700 mb-1">Clarification</p>
                    <p className="text-sm text-green-800">{confusion.clarification}</p>
                  </div>
                </div>
              )}

              {clarifyingId === confusion.id && (
                <div className="mt-3 pt-3 border-t space-y-2">
                  <Label className="text-xs">Clarification / Answer</Label>
                  <Textarea value={clarification} onChange={e => setClarification(e.target.value)} rows={2} placeholder="Provide the clarification or answer..." />
                  <div className="flex gap-2 justify-end">
                    <Button variant="outline" size="sm" onClick={() => setClarifyingId(null)}>Cancel</Button>
                    <Button size="sm" onClick={() => handleClarify(confusion)} disabled={!clarification.trim() || isSubmitting}>
                      {isSubmitting ? 'Saving...' : 'Save Clarification'}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
