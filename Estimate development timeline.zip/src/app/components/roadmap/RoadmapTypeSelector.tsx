import React from 'react';
import { Package, Code, Network } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '../ui/tabs';
import { RoadmapType, ROADMAP_TYPES } from '../../types/roadmap';

interface RoadmapTypeSelectorProps {
  selectedType: RoadmapType;
  onTypeChange: (type: RoadmapType) => void;
}

const typeIcons: Record<RoadmapType, React.ReactNode> = {
  product: <Package className="w-4 h-4 mr-2" />,
  technical: <Code className="w-4 h-4 mr-2" />,
  architectural: <Network className="w-4 h-4 mr-2" />,
};

export function RoadmapTypeSelector({ selectedType, onTypeChange }: RoadmapTypeSelectorProps) {
  return (
    <Tabs value={selectedType} onValueChange={(v) => onTypeChange(v as RoadmapType)}>
      <TabsList className="grid w-full grid-cols-3">
        {ROADMAP_TYPES.map((type) => (
          <TabsTrigger key={type.value} value={type.value} className="flex items-center">
            {typeIcons[type.value]}
            <span className="hidden sm:inline">{type.label}</span>
            <span className="sm:hidden">{type.value.charAt(0).toUpperCase() + type.value.slice(1)}</span>
          </TabsTrigger>
        ))}
      </TabsList>
    </Tabs>
  );
}
