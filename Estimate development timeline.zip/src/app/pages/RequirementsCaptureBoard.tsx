import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useParams } from 'react-router';
import { ArrowLeft, Plus, Filter, Search, FileText, Bug, Zap, Code, Download, Upload, Sparkles, Target, Layers, ChevronDown } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Requirement, RequirementType, RequirementStatus } from '../types/requirements';
import { BRDImportModal } from '../components/BRDImportModal';
import { toast } from 'sonner';

export default function RequirementsCaptureBoard() {
  const navigate = useNavigate();
  const { projectId } = useParams<{ projectId: string }>();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<RequirementType | 'all'>('all');
  const [requirements, setRequirements] = useState<Requirement[]>([]);
  const [showImportModal, setShowImportModal] = useState(false);
  const [selectedSprint, setSelectedSprint] = useState<string>('all');
  const [selectedPI, setSelectedPI] = useState<string>('all');
  const [showSprintContext, setShowSprintContext] = useState(false);

  // Load requirements from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(`requirements_${projectId}`);
    if (stored) {
      try {
        setRequirements(JSON.parse(stored));
      } catch (e) {
        console.error('Failed to parse stored requirements:', e);
      }
    }
  }, [projectId]);

  // Save requirements to localStorage whenever they change
  useEffect(() => {
    if (requirements.length > 0 && projectId) {
      localStorage.setItem(`requirements_${projectId}`, JSON.stringify(requirements));
    }
  }, [requirements, projectId]);

  // Filtered requirements based on PI and Sprint selection
  const filteredRequirements = useMemo(() => {
    let filtered = requirements;

    // Filter by PI
    if (selectedPI !== 'all') {
      filtered = filtered.filter(req => req.programIncrement === selectedPI);
    }

    // Filter by Sprint
    if (selectedSprint !== 'all') {
      filtered = filtered.filter(req => req.sprint === selectedSprint);
    }

    // Filter by type
    if (selectedType !== 'all') {
      filtered = filtered.filter(req => req.type === selectedType);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(req =>
        req.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        req.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    return filtered;
  }, [requirements, selectedPI, selectedSprint, selectedType, searchQuery]);

  const requirementTypes: { value: RequirementType; label: string; icon: string; color: string }[] = [
    { value: 'new_screen', label: 'New Screen', icon: '🖥️', color: 'blue' },
    { value: 'update_screen', label: 'Update Screen', icon: '✏️', color: 'purple' },
    { value: 'bug_fix', label: 'Bug Fix', icon: '🐛', color: 'red' },
    { value: 'feature_change', label: 'Feature Change', icon: '⚡', color: 'yellow' },
    { value: 'api_development', label: 'API Development', icon: '🔌', color: 'green' },
    { value: 'integration', label: 'Integration', icon: '🔗', color: 'orange' },
    { value: 'data_migration', label: 'Data Migration', icon: '📦', color: 'cyan' },
    { value: 'performance', label: 'Performance', icon: '⚡', color: 'pink' },
    { value: 'security', label: 'Security', icon: '🔒', color: 'indigo' },
    { value: 'ui_ux_change', label: 'UI/UX Change', icon: '🎨', color: 'teal' },
  ];

  const stats = [
    { label: 'Total Requirements', value: filteredRequirements.length, icon: FileText, color: 'bg-blue-500' },
    { label: 'In Progress', value: filteredRequirements.filter(r => r.status === 'in_progress').length, icon: Zap, color: 'bg-yellow-500' },
    { label: 'Completed', value: filteredRequirements.filter(r => r.status === 'completed').length, icon: Code, color: 'bg-green-500' },
    { label: 'Critical', value: filteredRequirements.filter(r => r.priority === 'critical').length, icon: Bug, color: 'bg-red-500' },
  ];

  const handleCreateNew = () => {
    if (projectId) {
      navigate(`/projects/${projectId}/requirements/add`);
    } else {
      toast.error('Project ID is missing');
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-green-100 text-green-700 border-green-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getStatusColor = (status: RequirementStatus) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-700';
      case 'review': return 'bg-blue-100 text-blue-700';
      case 'approved': return 'bg-green-100 text-green-700';
      case 'in_progress': return 'bg-yellow-100 text-yellow-700';
      case 'completed': return 'bg-purple-100 text-purple-700';
      case 'rejected': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  // Show sprint context panel when a specific sprint is selected
  useEffect(() => {
    setShowSprintContext(selectedPI !== 'all' || selectedSprint !== 'all');
  }, [selectedPI, selectedSprint]);

  return (
    <div className="container max-w-7xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        {/* Breadcrumb / Back Navigation */}
        {projectId && (
          <Button
            variant="ghost"
            onClick={() => navigate(`/projects/${projectId}`)}
            className="mb-4 -ml-2"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Project
          </Button>
        )}
        
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Requirements Board</h1>
            <p className="text-muted-foreground mt-1">Project-wide requirements across all modules</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => setShowImportModal(true)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Upload className="w-4 h-4 mr-2" />
              Import from BRD
            </Button>
            {projectId && (
              <Button
                onClick={() => navigate(`/projects/${projectId}/requirements/comprehensive`)}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Comprehensive View
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* PI & Sprint Filters */}
      <Card className="mb-6 border-2 border-blue-200">
        <CardHeader>
          <div className="flex items-center gap-4">
            <Layers className="w-6 h-6 text-blue-600" />
            <div>
              <CardTitle>Filter by Program Increment & Sprint</CardTitle>
              <CardDescription>View requirements for specific PI/Sprint or see all</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Program Increment</label>
              <select
                value={selectedPI}
                onChange={(e) => setSelectedPI(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 bg-white"
              >
                <option value="all">All Program Increments</option>
                <option value="PI-1">PI 1 (Jan - Mar 2024)</option>
                <option value="PI-2">PI 2 (Apr - Jun 2024)</option>
                <option value="PI-3">PI 3 (Jul - Sep 2024)</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Sprint</label>
              <select
                value={selectedSprint}
                onChange={(e) => setSelectedSprint(e.target.value)}
                className="w-full border border-gray-300 rounded-md px-3 py-2 bg-white"
              >
                <option value="all">All Sprints</option>
                <option value="Sprint-1">Sprint 1 (Week 1-2)</option>
                <option value="Sprint-2">Sprint 2 (Week 3-4)</option>
                <option value="Sprint-3">Sprint 3 (Week 5-6)</option>
                <option value="Sprint-4">Sprint 4 (Week 7-8)</option>
                <option value="Sprint-5">Sprint 5 (Week 9-10)</option>
                <option value="Sprint-6">Sprint 6 (Week 11-12)</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sprint Context Panel - Only shown when specific PI/Sprint selected */}
      {showSprintContext && (
        <Card className="mb-6 border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-blue-50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Target className="w-6 h-6 text-purple-600" />
                <div>
                  <CardTitle>
                    {selectedPI !== 'all' && selectedSprint !== 'all' 
                      ? `${selectedPI} - ${selectedSprint}` 
                      : selectedPI !== 'all' 
                        ? selectedPI 
                        : selectedSprint}
                  </CardTitle>
                  <CardDescription>Sprint planning and BRD documents</CardDescription>
                </div>
              </div>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export Sprint Backlog
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Sprint Goals */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Target className="w-5 h-5 text-green-600" />
                  <h3 className="font-semibold">Sprint Goals</h3>
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-white rounded-lg border border-gray-200">
                    <div className="flex items-start gap-2">
                      <div className="w-2 h-2 rounded-full bg-green-500 mt-1.5"></div>
                      <div className="flex-1">
                        <div className="font-medium text-sm">Complete patient registration module</div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {filteredRequirements.length} requirements • {filteredRequirements.reduce((acc, r) => acc + (r.estimatedHours || 0), 0)} hours estimated
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <Button variant="link" size="sm" className="mt-2 px-0">+ Add Sprint Goal</Button>
              </div>

              {/* BRD Documents */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <FileText className="w-5 h-5 text-purple-600" />
                  <h3 className="font-semibold">BRD Documents</h3>
                </div>
                <div className="space-y-2">
                  <div className="p-3 bg-white rounded-lg border border-gray-200 hover:border-purple-300 cursor-pointer transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="font-medium text-sm">BRD_PatientModule_v2.1.pdf</div>
                        <div className="text-xs text-muted-foreground mt-1">Uploaded: Jan 15, 2024 • 12 req extracted</div>
                      </div>
                      <Badge className="bg-green-100 text-green-700 text-xs">Processed</Badge>
                    </div>
                  </div>
                </div>
                <Button
                  variant="link"
                  size="sm"
                  className="mt-2 px-0"
                  onClick={() => setShowImportModal(true)}
                >
                  + Upload New BRD
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {stats.map((stat, idx) => (
          <Card key={idx}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
                <div className={`w-12 h-12 rounded-lg ${stat.color} flex items-center justify-center`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters & Search */}
      <Card className="mb-6">
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search requirements..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>
            <Button onClick={handleCreateNew} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Requirement
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Requirement Types Quick Filter */}
      <div className="flex gap-2 mb-6 flex-wrap">
        <Button
          variant={selectedType === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setSelectedType('all')}
        >
          All ({requirements.length})
        </Button>
        {requirementTypes.map((type) => (
          <Button
            key={type.value}
            variant={selectedType === type.value ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSelectedType(type.value)}
          >
            <span className="mr-1">{type.icon}</span>
            {type.label} ({requirements.filter(r => r.type === type.value).length})
          </Button>
        ))}
      </div>

      {/* Requirements List */}
      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="draft">Draft</TabsTrigger>
          <TabsTrigger value="review">In Review</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="in_progress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          {filteredRequirements.length === 0 ? (
            <Card>
              <CardContent className="py-16 text-center">
                <FileText className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">
                  {requirements.length === 0 ? 'No Requirements Yet' : 'No Requirements Match Filters'}
                </h3>
                <p className="text-muted-foreground mb-6">
                  {requirements.length === 0 
                    ? 'Start by adding your first requirement' 
                    : 'Try adjusting your filters or search criteria'}
                </p>
                {requirements.length === 0 && (
                  <Button onClick={handleCreateNew} className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add First Requirement
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredRequirements.map((req) => (
                <RequirementCard key={req.id} requirement={req} projectId={projectId} />
              ))}
            </div>
          )}
        </TabsContent>

        {/* Other status tabs */}
        {(['draft', 'review', 'approved', 'in_progress', 'completed'] as RequirementStatus[]).map((status) => (
          <TabsContent key={status} value={status} className="mt-6">
            <div className="space-y-4">
              {filteredRequirements.filter(r => r.status === status).map((req) => (
                <RequirementCard key={req.id} requirement={req} projectId={projectId} />
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Quick Create Templates */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Quick Start Templates</CardTitle>
          <CardDescription>Use these templates for common requirement types</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card 
              className="cursor-pointer hover:shadow-md transition-shadow" 
              onClick={() => {
                if (projectId) {
                  navigate(`/projects/${projectId}/requirements/add?template=new_screen`);
                }
              }}
            >
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">🖥️</div>
                <div className="font-semibold">New Screen</div>
                <div className="text-sm text-muted-foreground">Create a brand new screen/page</div>
              </CardContent>
            </Card>
            <Card 
              className="cursor-pointer hover:shadow-md transition-shadow" 
              onClick={() => {
                if (projectId) {
                  navigate(`/projects/${projectId}/requirements/add?template=bug_fix`);
                }
              }}
            >
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">🐛</div>
                <div className="font-semibold">Bug Fix</div>
                <div className="text-sm text-muted-foreground">Report and track a bug</div>
              </CardContent>
            </Card>
            <Card 
              className="cursor-pointer hover:shadow-md transition-shadow" 
              onClick={() => {
                if (projectId) {
                  navigate(`/projects/${projectId}/requirements/add?template=feature_change`);
                }
              }}
            >
              <CardContent className="pt-6">
                <div className="text-3xl mb-2">⚡</div>
                <div className="font-semibold">Feature Change</div>
                <div className="text-sm text-muted-foreground">Modify existing functionality</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      {/* BRD Import Modal */}
      <BRDImportModal
        open={showImportModal}
        onClose={() => setShowImportModal(false)}
        onImportComplete={(extractedReqs, analysisResult) => {
          const newReqs: Requirement[] = extractedReqs.map((req, idx) => ({
            id: `imported-${Date.now()}-${idx}`,
            projectId: projectId || 'unknown',
            type: req.type,
            title: req.title,
            description: req.description,
            programIncrement: selectedPI !== 'all' ? selectedPI : undefined,
            sprint: selectedSprint !== 'all' ? selectedSprint : undefined,
            moduleIds: [],
            businessValue: '',
            userStory: req.userStory,
            affectedScreens: req.affectedScreens,
            affectedAPIs: req.affectedAPIs,
            affectedComponents: [],
            technicalNotes: req.technicalNotes,
            acceptanceCriteria: req.acceptanceCriteria.map((ac, acIdx) => ({
              id: `ac-${idx}-${acIdx}`,
              description: ac,
              completed: false,
            })),
            dependencies: [],
            blockers: [],
            complexity: req.complexity,
            estimatedHours: req.estimatedHours,
            priority: req.priority,
            status: 'draft',
            assignedTo: undefined,
            createdBy: 'current-user',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            attachments: [],
            comments: [],
          }));
          
          setRequirements([...requirements, ...newReqs]);
          toast.success(`Imported ${newReqs.length} requirements from BRD!`);
        }}
        projectId={projectId || 'unknown'}
        moduleId="not-applicable"
      />
    </div>
  );
}

// Requirement Card Component
function RequirementCard({ requirement, projectId }: { requirement: Requirement; projectId?: string }) {
  const navigate = useNavigate();
  const [showMoveMenu, setShowMoveMenu] = useState(false);
  
  const typeConfig = {
    new_screen: { icon: '🖥️', color: 'blue' },
    update_screen: { icon: '✏️', color: 'purple' },
    bug_fix: { icon: '🐛', color: 'red' },
    feature_change: { icon: '⚡', color: 'yellow' },
    api_development: { icon: '🔌', color: 'green' },
    integration: { icon: '🔗', color: 'orange' },
    data_migration: { icon: '📦', color: 'cyan' },
    performance: { icon: '⚡', color: 'pink' },
    security: { icon: '🔒', color: 'indigo' },
    ui_ux_change: { icon: '🎨', color: 'teal' },
  };

  const config = typeConfig[requirement.type];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-700';
      case 'high': return 'bg-orange-100 text-orange-700';
      case 'medium': return 'bg-yellow-100 text-yellow-700';
      case 'low': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const handleMoveRequirement = (newPI: string, newSprint: string) => {
    const storageKey = `requirements_${projectId}`;
    const stored = localStorage.getItem(storageKey);
    if (!stored) return;
    
    const requirements = JSON.parse(stored);
    const updatedReqs = requirements.map((req: Requirement) => {
      if (req.id === requirement.id) {
        return {
          ...req,
          programIncrement: newPI || undefined,
          sprint: newSprint || undefined,
        };
      }
      return req;
    });
    
    localStorage.setItem(storageKey, JSON.stringify(updatedReqs));
    toast.success('Requirement moved successfully!');
    window.location.reload(); // Refresh to show updated data
  };

  return (
    <Card 
      className="cursor-pointer hover:shadow-md transition-shadow relative" 
    >
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div className="text-3xl">{config.icon}</div>
          <div className="flex-1" onClick={() => navigate(`/projects/${projectId}/requirements/${requirement.id}/edit`)}>
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-lg">{requirement.title}</h3>
                  {requirement.programIncrement && (
                    <Badge variant="outline" className="text-xs">{requirement.programIncrement}</Badge>
                  )}
                  {requirement.sprint && (
                    <Badge variant="outline" className="text-xs">{requirement.sprint}</Badge>
                  )}
                </div>
                <p className="text-sm text-muted-foreground line-clamp-2">{requirement.description}</p>
              </div>
              <div className="flex gap-2 ml-4">
                <Badge className={getPriorityColor(requirement.priority)}>
                  {requirement.priority}
                </Badge>
                <Badge variant="secondary">{requirement.status}</Badge>
              </div>
            </div>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span>Complexity: {requirement.complexity}</span>
              {requirement.estimatedHours && <span>Est: {requirement.estimatedHours}h</span>}
              {requirement.acceptanceCriteria.length > 0 && (
                <span>
                  AC: {requirement.acceptanceCriteria.filter(ac => ac.completed).length}/{requirement.acceptanceCriteria.length}
                </span>
              )}
              {requirement.moduleIds.length > 0 && (
                <span>Modules: {requirement.moduleIds.length}</span>
              )}
            </div>
          </div>
          
          {/* Move to PI/Sprint Dropdown */}
          <div className="relative" onClick={(e) => e.stopPropagation()}>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowMoveMenu(!showMoveMenu)}
            >
              <span className="mr-1">📅</span>
              Move
            </Button>
            
            {showMoveMenu && (
              <div className="absolute right-0 top-full mt-2 w-80 bg-white border rounded-lg shadow-lg z-10 p-4">
                <div className="mb-3">
                  <h4 className="font-semibold text-sm mb-2">Move to PI/Sprint</h4>
                  <p className="text-xs text-muted-foreground">Quick assignment to different PI or Sprint</p>
                </div>
                
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => {
                        handleMoveRequirement('', '');
                        setShowMoveMenu(false);
                      }}
                    >
                      📦 Backlog
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-xs"
                      onClick={() => {
                        handleMoveRequirement('PI-1', '');
                        setShowMoveMenu(false);
                      }}
                    >
                      PI-1 Backlog
                    </Button>
                  </div>
                  
                  <div className="border-t pt-2">
                    <p className="text-xs font-medium mb-2">PI-1 Sprints:</p>
                    <div className="grid grid-cols-2 gap-2">
                      {['Sprint-1', 'Sprint-2', 'Sprint-3', 'Sprint-4', 'Sprint-5', 'Sprint-6'].map((sprint) => (
                        <Button
                          key={sprint}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => {
                            handleMoveRequirement('PI-1', sprint);
                            setShowMoveMenu(false);
                          }}
                        >
                          {sprint}
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="border-t pt-2">
                    <p className="text-xs font-medium mb-2">Other PIs:</p>
                    <div className="grid grid-cols-2 gap-2">
                      {['PI-2', 'PI-3', 'PI-4'].map((pi) => (
                        <Button
                          key={pi}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          onClick={() => {
                            handleMoveRequirement(pi, '');
                            setShowMoveMenu(false);
                          }}
                        >
                          {pi} Backlog
                        </Button>
                      ))}
                    </div>
                  </div>
                </div>
                
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-3 text-xs"
                  onClick={() => setShowMoveMenu(false)}
                >
                  Cancel
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}