/**
 * Knowledge Hub Store
 * Manages documents, meetings, emails, chats, and AI requirements
 */

import { create } from 'zustand';
import { toast } from 'sonner';
import { db } from '../lib/db';
import { analyzeRequirements, searchKnowledgeHub, summarizeHub, listOpenItems, generateRiskBrief } from '../lib/ai/bedrock';
import type {
  Document,
  Meeting,
  Email,
  Chat,
  AIRequirement,
  KnowledgeHub,
  CreateDocumentDTO,
  CreateMeetingDTO,
  CreateEmailDTO,
  CreateChatDTO,
} from '../types/knowledge-hub';
import type { FormalRequirement } from '../lib/db/types';

export interface AISearchResult {
  answer: string;
  sources: { type: string; id: string; title: string; excerpt: string }[];
  confidence: number;
}

interface KnowledgeHubState {
  // Data
  currentHub: KnowledgeHub | null;
  isLoading: boolean;
  isAnalyzing: boolean;
  isSearching: boolean;
  lastSearchResult: AISearchResult | null;
  
  // Actions
  fetchKnowledgeHub: (roadmapItemId: string) => Promise<void>;
  
  // Document actions
  uploadDocument: (data: CreateDocumentDTO) => Promise<Document | null>;
  deleteDocument: (documentId: string) => Promise<boolean>;
  getDocumentDownloadUrl: (documentId: string) => Promise<string | null>;
  
  // Meeting actions
  createMeeting: (data: CreateMeetingDTO) => Promise<Meeting | null>;
  updateMeeting: (meetingId: string, data: Partial<Meeting>) => Promise<boolean>;
  deleteMeeting: (meetingId: string) => Promise<boolean>;
  
  // Document actions
  updateDocument: (documentId: string, data: Pick<Document, 'name' | 'type' | 'version'>) => Promise<boolean>;

  // Email actions
  createEmail: (data: CreateEmailDTO) => Promise<Email | null>;
  updateEmail: (emailId: string, data: Partial<Omit<Email, 'id' | 'roadmapItemId' | 'createdAt'>>) => Promise<boolean>;
  deleteEmail: (emailId: string) => Promise<boolean>;

  // Chat actions
  createChat: (data: CreateChatDTO) => Promise<Chat | null>;
  updateChat: (chatId: string, data: Partial<Omit<Chat, 'id' | 'roadmapItemId' | 'createdAt'>>) => Promise<boolean>;
  deleteChat: (chatId: string) => Promise<boolean>;
  
  // AI Search + Command actions
  aiSearch: (question: string) => Promise<boolean>;
  runCommand: (command: string) => Promise<{ type: 'text'; content: string } | { type: 'navigate'; tab: string } | { type: 'export'; format: 'excel' | 'pptx' | 'both' } | null>;

  // AI Requirements actions
  analyzeAllSources: (roadmapItemId: string, noDocumentMode?: boolean) => Promise<boolean>;
  deleteAIRequirement: (requirementId: string) => Promise<boolean>;

  // Formal Requirements actions
  createFormalRequirement: (data: Omit<FormalRequirement, 'id' | 'createdAt' | 'updatedAt'>) => Promise<boolean>;
  updateFormalRequirement: (id: string, updates: Partial<FormalRequirement>) => Promise<boolean>;
  deleteFormalRequirement: (id: string) => Promise<boolean>;

  // Reset
  reset: () => void;
}

export const useKnowledgeHubStore = create<KnowledgeHubState>((set, get) => ({
  currentHub: null,
  isLoading: false,
  isAnalyzing: false,
  isSearching: false,
  lastSearchResult: null,
  
  /**
   * Fetch all knowledge hub data for a roadmap item
   */
  fetchKnowledgeHub: async (roadmapItemId: string) => {
    set({ isLoading: true });
    try {
      const [documents, meetings, emails, chats, aiRequirements, gaps, confusions, suggestions, securityRequirements, threats, nfrs, cloudGovernance, formalRequirements] = await Promise.all([
        db.documents.getByRoadmapItem(roadmapItemId),
        db.meetings.getByRoadmapItem(roadmapItemId),
        db.emails.getByRoadmapItem(roadmapItemId),
        db.chats.getByRoadmapItem(roadmapItemId),
        db.aiRequirements.getByRoadmapItem(roadmapItemId),
        db.gaps.getByRoadmapItem(roadmapItemId),
        db.confusions.getByRoadmapItem(roadmapItemId),
        db.suggestions.getByRoadmapItem(roadmapItemId),
        db.securityRequirements.getByRoadmapItem(roadmapItemId),
        db.threats.getByRoadmapItem(roadmapItemId),
        db.nfrs.getByRoadmapItem(roadmapItemId),
        db.cloudGovernance.getByRoadmapItem(roadmapItemId),
        db.formalRequirements.getByRoadmapItem(roadmapItemId),
      ]);
      const hub: KnowledgeHub = {
        roadmapItemId,
        documents,
        meetings,
        emails,
        chats,
        aiRequirements,
        gaps,
        confusions,
        suggestions,
        securityRequirements,
        threats,
        nfrs,
        cloudGovernance,
        formalRequirements,
        stats: {
          totalDocuments: documents.length,
          totalMeetings: meetings.length,
          totalEmails: emails.length,
          totalChats: chats.length,
          totalAIRequirements: aiRequirements.length,
        },
      };
      set({ currentHub: hub, isLoading: false });
    } catch (error) {
      console.error('Error fetching knowledge hub:', error);
      toast.error('Failed to load knowledge hub');
      set({ isLoading: false });
    }
  },
  
  /**
   * Upload a document
   */
  uploadDocument: async (data: CreateDocumentDTO) => {
    try {
      const document = await db.documents.create({
        roadmapItemId: data.roadmapItemId,
        name: data.name,
        type: data.type,
        version: data.version,
        storagePath: '',
        fileSize: data.file.size,
      }, data.file);
      toast.success('Document uploaded successfully');
      await get().fetchKnowledgeHub(data.roadmapItemId);
      return document;
    } catch (error: any) {
      console.error('Error uploading document:', error);

      // Check if it's a Firebase Storage permission error
      if (error?.code === 'storage/unauthorized' || error?.message?.includes('unauthorized')) {
        toast.error('Upload blocked: Firebase Storage rules need to be updated. Check FIREBASE-STORAGE-FIX.md');
      } else {
        toast.error(`Failed to upload document: ${error?.message || 'Unknown error'}`);
      }
      return null;
    }
  },
  
  /**
   * Delete a document
   */
  deleteDocument: async (documentId: string) => {
    try {
      await db.documents.delete(documentId);
      toast.success('Document deleted');
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            documents: state.currentHub.documents.filter(d => d.id !== documentId),
            stats: {
              ...state.currentHub.stats,
              totalDocuments: state.currentHub.stats.totalDocuments - 1,
            },
          },
        };
      });
      return true;
    } catch (error) {
      console.error('Error deleting document:', error);
      toast.error('Failed to delete document');
      return false;
    }
  },
  
  /**
   * Get signed download URL for a document
   */
  getDocumentDownloadUrl: async (documentId: string) => {
    try {
      return await db.documents.getDownloadUrl(documentId);
    } catch (error) {
      console.error('Error getting download URL:', error);
      toast.error('Failed to get download URL');
      return null;
    }
  },
  
  /**
   * Create a meeting
   */
  createMeeting: async (data: CreateMeetingDTO) => {
    try {
      const meeting = await db.meetings.create(data);
      toast.success('Meeting added successfully');

      // Refresh knowledge hub
      await get().fetchKnowledgeHub(data.roadmapItemId);

      return meeting;
    } catch (error) {
      console.error('Error creating meeting:', error);
      toast.error('Failed to create meeting');
      return null;
    }
  },
  
  /**
   * Update a meeting
   */
  updateMeeting: async (meetingId: string, data: Partial<Meeting>) => {
    try {
      await db.meetings.update(meetingId, data);
      toast.success('Meeting updated');

      // Update local state
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            meetings: state.currentHub.meetings.map(m =>
              m.id === meetingId ? { ...m, ...data } : m
            ),
          },
        };
      });

      return true;
    } catch (error) {
      console.error('Error updating meeting:', error);
      toast.error('Failed to update meeting');
      return false;
    }
  },
  
  /**
   * Delete a meeting
   */
  deleteMeeting: async (meetingId: string) => {
    try {
      await db.meetings.delete(meetingId);
      toast.success('Meeting deleted');

      // Update local state
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            meetings: state.currentHub.meetings.filter(m => m.id !== meetingId),
            stats: {
              ...state.currentHub.stats,
              totalMeetings: state.currentHub.stats.totalMeetings - 1,
            },
          },
        };
      });

      return true;
    } catch (error) {
      console.error('Error deleting meeting:', error);
      toast.error('Failed to delete meeting');
      return false;
    }
  },
  
  /**
   * Create an email
   */
  updateDocument: async (documentId: string, data: Pick<Document, 'name' | 'type' | 'version'>) => {
    try {
      const updated = await db.documents.update(documentId, data);
      toast.success('Document updated');
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            documents: state.currentHub.documents.map(d => d.id === documentId ? { ...d, ...updated } : d),
          },
        };
      });
      return true;
    } catch (error) {
      console.error('Error updating document:', error);
      toast.error('Failed to update document');
      return false;
    }
  },

  createEmail: async (data: CreateEmailDTO) => {
    try {
      const email = await db.emails.create(data);
      toast.success('Email added successfully');

      // Refresh knowledge hub
      await get().fetchKnowledgeHub(data.roadmapItemId);

      return email;
    } catch (error) {
      console.error('Error creating email:', error);
      toast.error('Failed to create email');
      return null;
    }
  },
  
  /**
   * Delete an email
   */
  deleteEmail: async (emailId: string) => {
    try {
      await db.emails.delete(emailId);
      toast.success('Email deleted');

      // Update local state
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            emails: state.currentHub.emails.filter(e => e.id !== emailId),
            stats: {
              ...state.currentHub.stats,
              totalEmails: state.currentHub.stats.totalEmails - 1,
            },
          },
        };
      });

      return true;
    } catch (error) {
      console.error('Error deleting email:', error);
      toast.error('Failed to delete email');
      return false;
    }
  },
  
  /**
   * Create a chat
   */
  updateEmail: async (emailId: string, data: Partial<Omit<Email, 'id' | 'roadmapItemId' | 'createdAt'>>) => {
    try {
      const updated = await db.emails.update(emailId, data);
      toast.success('Email updated');
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            emails: state.currentHub.emails.map(e => e.id === emailId ? { ...e, ...updated } : e),
          },
        };
      });
      return true;
    } catch (error) {
      console.error('Error updating email:', error);
      toast.error('Failed to update email');
      return false;
    }
  },

  updateChat: async (chatId: string, data: Partial<Omit<Chat, 'id' | 'roadmapItemId' | 'createdAt'>>) => {
    try {
      const updated = await db.chats.update(chatId, data);
      toast.success('Chat updated');
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            chats: state.currentHub.chats.map(c => c.id === chatId ? { ...c, ...updated } : c),
          },
        };
      });
      return true;
    } catch (error) {
      console.error('Error updating chat:', error);
      toast.error('Failed to update chat');
      return false;
    }
  },

  createChat: async (data: CreateChatDTO) => {
    try {
      const chat = await db.chats.create(data);
      toast.success('Chat added successfully');

      // Refresh knowledge hub
      await get().fetchKnowledgeHub(data.roadmapItemId);

      return chat;
    } catch (error) {
      console.error('Error creating chat:', error);
      toast.error('Failed to create chat');
      return null;
    }
  },
  
  /**
   * Delete a chat
   */
  deleteChat: async (chatId: string) => {
    try {
      await db.chats.delete(chatId);
      toast.success('Chat deleted');

      // Update local state
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            chats: state.currentHub.chats.filter(c => c.id !== chatId),
            stats: {
              ...state.currentHub.stats,
              totalChats: state.currentHub.stats.totalChats - 1,
            },
          },
        };
      });

      return true;
    } catch (error) {
      console.error('Error deleting chat:', error);
      toast.error('Failed to delete chat');
      return false;
    }
  },
  
  // ── AI Search ───────────────────────────────────────────────────────────

  aiSearch: async (question: string) => {
    const hub = get().currentHub;
    if (!hub) { toast.error('No knowledge hub loaded'); return false; }

    set({ isSearching: true, lastSearchResult: null });
    try {
      const result = await searchKnowledgeHub(question, {
        documents: hub.documents.map(d => ({
          id: d.id, name: d.name, content: (d as any).extractedText || d.name,
        })),
        meetings: hub.meetings.map(m => ({
          id: m.id, title: m.title, notes: (m as any).transcript || (m as any).notes || '',
        })),
        emails: hub.emails.map(e => ({
          id: e.id, subject: e.subject, body: e.body,
        })),
        chats: hub.chats.map(c => ({
          id: c.id, title: (c as any).title, content: c.messages,
        })),
        formalRequirements: (hub.formalRequirements ?? []).map((r: any) => ({
          id: r.id, requirementId: r.requirementId, title: r.title,
          description: r.description, category: r.category,
        })),
        gaps: (hub.gaps ?? []).map((g: any) => ({
          id: g.id, title: g.title, description: g.description, status: g.status,
        })),
      });
      set({ lastSearchResult: result, isSearching: false });
      return true;
    } catch (err) {
      console.error('AI search error:', err);
      toast.error('Search failed — please try again');
      set({ isSearching: false });
      return false;
    }
  },

  runCommand: async (command: string) => {
    const hub = get().currentHub;
    if (!hub) return null;

    // Navigation commands — no AI needed
    const navMap: Record<string, string> = {
      '/gaps':         'gaps',
      '/threats':      'threats',
      '/security':     'security',
      '/nfr':          'nfrs',
      '/requirements': 'requirements',
      '/documents':    'documents',
      '/meetings':     'meetings',
      '/emails':       'emails',
      '/chats':        'chats',
    };
    if (navMap[command]) return { type: 'navigate', tab: navMap[command] };

    // Export commands — no AI needed
    if (command === '/excel') return { type: 'export', format: 'excel' };
    if (command === '/pptx')  return { type: 'export', format: 'pptx' };
    if (command === '/export') return { type: 'export', format: 'both' };

    // Filter shortcuts — run as AI search queries
    const filterMap: Record<string, string> = {
      '/critical': 'List all critical priority requirements and critical/high severity gaps and threats',
      '/approved': 'List all approved requirements and what has been formally signed off',
      '/pending':  'List all requirements still in Draft or Under Review that need attention',
    };
    if (filterMap[command]) {
      set({ isSearching: true, lastSearchResult: null });
      try {
        const result = await searchKnowledgeHub(filterMap[command], {
          documents: hub.documents.map(d => ({ id: d.id, name: d.name, content: (d as any).extractedText || d.name })),
          meetings:  hub.meetings.map(m => ({ id: m.id, title: m.title, notes: (m as any).transcript || '' })),
          emails:    hub.emails.map(e => ({ id: e.id, subject: e.subject, body: e.body })),
          chats:     hub.chats.map(c => ({ id: c.id, title: (c as any).title, content: c.messages })),
          formalRequirements: (hub.formalRequirements ?? []).map((r: any) => ({ id: r.id, requirementId: r.requirementId, title: r.title, description: r.description, category: r.category })),
          gaps: (hub.gaps ?? []).map((g: any) => ({ id: g.id, title: g.title, description: g.description, status: g.status })),
        });
        set({ lastSearchResult: result, isSearching: false });
        return { type: 'text', content: result.answer };
      } catch {
        set({ isSearching: false });
        return null;
      }
    }

    // AI commands
    set({ isSearching: true, lastSearchResult: null });
    try {
      let text = '';

      if (command === '/summary') {
        text = await summarizeHub({
          documents: hub.documents, meetings: hub.meetings,
          emails: hub.emails, chats: hub.chats,
          formalRequirements: hub.formalRequirements ?? [],
          gaps: hub.gaps ?? [], confusions: hub.confusions ?? [],
          suggestions: hub.suggestions ?? [],
          securityRequirements: hub.securityRequirements ?? [],
          threats: hub.threats ?? [], nfrs: hub.nfrs ?? [],
        });
      } else if (command === '/openitems') {
        text = await listOpenItems({ gaps: hub.gaps ?? [], confusions: hub.confusions ?? [] });
      } else if (command === '/risks') {
        text = await generateRiskBrief({
          threats: hub.threats ?? [], gaps: hub.gaps ?? [],
          securityRequirements: hub.securityRequirements ?? [],
        });
      } else if (command === '/analyze') {
        // Trigger full analysis — handled externally, just signal it
        set({ isSearching: false });
        return { type: 'text', content: '__TRIGGER_ANALYZE__' };
      }

      set({
        lastSearchResult: { answer: text, sources: [], confidence: 100 },
        isSearching: false,
      });
      return { type: 'text', content: text };
    } catch (err) {
      console.error('Command error:', err);
      set({ isSearching: false });
      return null;
    }
  },

  /**
   * Analyze all sources with AWS Bedrock AI
   */
  analyzeAllSources: async (roadmapItemId: string, noDocumentMode = false) => {
    set({ isAnalyzing: true });

    try {
      const currentHub = get().currentHub;
      if (!currentHub) {
        toast.error('No knowledge hub data found');
        return false;
      }

      // Check if there are any sources to analyze
      const hasSources = currentHub.documents.length > 0 ||
                        currentHub.meetings.length > 0 ||
                        currentHub.emails.length > 0 ||
                        currentHub.chats.length > 0;

      if (!hasSources) {
        toast.error('No documents, meetings, emails, or chats to analyze');
        return false;
      }

      toast.info('Analyzing with AWS Bedrock AI...');

      // Prepare source texts
      const sourceTexts = {
        documents: currentHub.documents.map(doc => ({
          id: doc.id,
          name: doc.name,
          content: doc.extractedText || `Document: ${doc.name}`,
        })),
        meetings: currentHub.meetings.map(meeting => ({
          id: meeting.id,
          title: meeting.title,
          notes: meeting.transcript || meeting.notes || '',
        })),
        emails: currentHub.emails.map(email => ({
          id: email.id,
          subject: email.subject,
          body: email.body,
        })),
        chats: currentHub.chats.map(chat => ({
          id: chat.id,
          content: chat.messages,
        })),
      };

      // Call AWS Bedrock — noDocumentMode skips baseline requirement check
      const result = await analyzeRequirements({ roadmapItemId }, sourceTexts, noDocumentMode);

      // Save all results to Firestore in parallel
      const savePromises = [];

      // Save gaps
      if (result.gaps && result.gaps.length > 0) {
        result.gaps.forEach((gap: any) => {
          savePromises.push(db.gaps.create({
            roadmapItemId,
            title: gap.title,
            description: gap.description,
            severity: gap.severity,
            status: 'Open',
            sourceType: gap.source?.type || 'AI',
            sourceId: gap.source?.id,
            suggestions: gap.suggestions || [],
          }));
        });
      }

      // Save confusions
      if (result.confusions && result.confusions.length > 0) {
        result.confusions.forEach((confusion: any) => {
          savePromises.push(db.confusions.create({
            roadmapItemId,
            question: confusion.question,
            context: confusion.context,
            sources: confusion.sources || [],
            status: 'Open',
          }));
        });
      }

      // Save suggestions
      if (result.suggestions && result.suggestions.length > 0) {
        result.suggestions.forEach((suggestion: any) => {
          savePromises.push(db.suggestions.create({
            roadmapItemId,
            title: suggestion.title,
            description: suggestion.description,
            type: suggestion.type,
            impact: suggestion.impact,
            effort: suggestion.effort,
            status: 'Pending',
          }));
        });
      }

      // Save security requirements
      if (result.securityRequirements && result.securityRequirements.length > 0) {
        result.securityRequirements.forEach((secReq: any) => {
          savePromises.push(db.securityRequirements.create({
            roadmapItemId,
            title: secReq.title,
            description: secReq.description,
            category: secReq.category,
            level: secReq.level,
            standard: secReq.standard,
            controls: secReq.controls || [],
            testCriteria: secReq.testCriteria || [],
            status: 'Draft',
          }));
        });
      }

      // Save threats
      if (result.threats && result.threats.length > 0) {
        result.threats.forEach((threat: any) => {
          savePromises.push(db.threats.create({
            roadmapItemId,
            threat: threat.threat,
            description: threat.description,
            category: threat.category,
            level: threat.level,
            likelihood: threat.likelihood,
            impact: threat.impact,
            mitigations: threat.mitigations || [],
            status: 'Identified',
          }));
        });
      }

      // Save NFRs
      if (result.nfrs && result.nfrs.length > 0) {
        result.nfrs.forEach((nfr: any) => {
          savePromises.push(db.nfrs.create({
            roadmapItemId,
            category: nfr.category,
            requirement: nfr.requirement,
            metric: nfr.metric,
            target: nfr.target,
            measurement: nfr.measurement,
            priority: nfr.priority,
            status: 'Draft',
          }));
        });
      }

      // Save Cloud Governance
      if (result.cloudGovernance && result.cloudGovernance.length > 0) {
        result.cloudGovernance.forEach((cloudGov: any) => {
          savePromises.push(db.cloudGovernance.create({
            roadmapItemId,
            area: cloudGov.area,
            requirement: cloudGov.requirement,
            details: cloudGov.details,
            priority: cloudGov.priority,
            status: 'Draft',
          }));
        });
      }

      // Wait for all saves to complete
      await Promise.all(savePromises);

      toast.success(`AI Analysis complete! Found ${result.gaps?.length || 0} gaps, ${result.confusions?.length || 0} confusions, ${result.suggestions?.length || 0} suggestions, ${result.securityRequirements?.length || 0} security requirements, ${result.threats?.length || 0} threats, ${result.nfrs?.length || 0} NFRs, ${result.cloudGovernance?.length || 0} cloud governance`);

      // Refresh knowledge hub to show new data
      await get().fetchKnowledgeHub(roadmapItemId);

      return true;
    } catch (error: any) {
      console.error('Error analyzing sources:', error);
      toast.error(`AI analysis failed: ${error?.message || 'Unknown error'}`);
      return false;
    } finally {
      set({ isAnalyzing: false });
    }
  },
  
  /**
   * Delete an AI requirement
   */
  deleteAIRequirement: async (requirementId: string) => {
    try {
      await db.aiRequirements.delete(requirementId);
      toast.success('AI requirement deleted');

      // Update local state
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            aiRequirements: state.currentHub.aiRequirements.filter(r => r.id !== requirementId),
            stats: {
              ...state.currentHub.stats,
              totalAIRequirements: state.currentHub.stats.totalAIRequirements - 1,
            },
          },
        };
      });

      return true;
    } catch (error) {
      console.error('Error deleting AI requirement:', error);
      toast.error('Failed to delete AI requirement');
      return false;
    }
  },
  
  // ── Formal Requirements ─────────────────────────────────────────────────

  createFormalRequirement: async (data: Omit<FormalRequirement, 'id' | 'createdAt' | 'updatedAt'>) => {
    try {
      const created = await db.formalRequirements.create(data);
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            formalRequirements: [...(state.currentHub.formalRequirements ?? []), created],
          },
        };
      });
      toast.success('Requirement added');
      return true;
    } catch (error) {
      console.error('Error creating formal requirement:', error);
      toast.error('Failed to add requirement');
      return false;
    }
  },

  updateFormalRequirement: async (id: string, updates: Partial<FormalRequirement>) => {
    try {
      const updated = await db.formalRequirements.update(id, updates);
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            formalRequirements: (state.currentHub.formalRequirements ?? []).map((r: any) =>
              r.id === id ? { ...r, ...updated } : r
            ),
          },
        };
      });
      toast.success('Requirement updated');
      return true;
    } catch (error) {
      console.error('Error updating formal requirement:', error);
      toast.error('Failed to update requirement');
      return false;
    }
  },

  deleteFormalRequirement: async (id: string) => {
    try {
      await db.formalRequirements.delete(id);
      set((state) => {
        if (!state.currentHub) return state;
        return {
          currentHub: {
            ...state.currentHub,
            formalRequirements: (state.currentHub.formalRequirements ?? []).filter((r: any) => r.id !== id),
          },
        };
      });
      toast.success('Requirement deleted');
      return true;
    } catch (error) {
      console.error('Error deleting formal requirement:', error);
      toast.error('Failed to delete requirement');
      return false;
    }
  },

  /**
   * Reset store
   */
  reset: () => {
    set({
      currentHub: null,
      isLoading: false,
      isAnalyzing: false,
    });
  },
}));