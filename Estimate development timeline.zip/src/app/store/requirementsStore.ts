import { create } from 'zustand';
import { db } from '../lib/supabase';

export interface PI {
  id: string;
  projectId: string;
  name: string;
  startDate?: string;
  endDate?: string;
  status: string;
  objectives?: string;
  createdAt: string;
  updatedAt: string;
  sprints?: Sprint[];
}

export interface Sprint {
  id: string;
  projectId: string;
  piId?: string;
  name: string;
  startDate?: string;
  endDate?: string;
  status: string;
  goals?: string;
  createdAt: string;
  updatedAt: string;
  pi?: PI;
}

export interface Requirement {
  id: string;
  projectId: string;
  piId?: string;
  sprintId?: string;
  title: string;
  description?: string;
  category: string;
  priority: string;
  status: string;
  tags?: string[];
  metadata?: any;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  pi?: PI;
  sprint?: Sprint;
}

interface RequirementsState {
  pis: PI[];
  sprints: Sprint[];
  requirements: Requirement[];
  isLoading: boolean;

  // PI Actions
  fetchPIs: (projectId: string) => Promise<void>;
  createPI: (pi: Partial<PI>) => Promise<PI>;
  updatePI: (id: string, updates: Partial<PI>) => Promise<void>;
  deletePI: (id: string) => Promise<void>;

  // Sprint Actions
  fetchSprints: (projectId: string) => Promise<void>;
  createSprint: (sprint: Partial<Sprint>) => Promise<Sprint>;
  updateSprint: (id: string, updates: Partial<Sprint>) => Promise<void>;
  deleteSprint: (id: string) => Promise<void>;

  // Requirement Actions
  fetchRequirements: (projectId: string, filters?: any) => Promise<void>;
  createRequirement: (requirement: Partial<Requirement>) => Promise<Requirement>;
  updateRequirement: (id: string, updates: Partial<Requirement>) => Promise<void>;
  deleteRequirement: (id: string) => Promise<void>;
  bulkCreateRequirements: (projectId: string, requirements: Partial<Requirement>[]) => Promise<void>;
}

export const useRequirementsStore = create<RequirementsState>((set, get) => ({
  pis: [],
  sprints: [],
  requirements: [],
  isLoading: false,

  // PI Actions
  fetchPIs: async (projectId: string) => {
    set({ isLoading: true });
    try {
      const pis = await db.getPIs(projectId);
      set({ pis, isLoading: false });
    } catch (error) {
      console.error('Failed to fetch PIs:', error);
      set({ isLoading: false });
    }
  },

  createPI: async (pi: Partial<PI>) => {
    try {
      const created = await db.createPI(pi);
      set((state) => ({ pis: [...state.pis, created] }));
      return created;
    } catch (error) {
      console.error('Failed to create PI:', error);
      throw error;
    }
  },

  updatePI: async (id: string, updates: Partial<PI>) => {
    try {
      const updated = await db.updatePI(id, updates);
      set((state) => ({
        pis: state.pis.map((pi) => (pi.id === id ? { ...pi, ...updated } : pi)),
      }));
    } catch (error) {
      console.error('Failed to update PI:', error);
      throw error;
    }
  },

  deletePI: async (id: string) => {
    try {
      await db.deletePI(id);
      set((state) => ({
        pis: state.pis.filter((pi) => pi.id !== id),
      }));
    } catch (error) {
      console.error('Failed to delete PI:', error);
      throw error;
    }
  },

  // Sprint Actions
  fetchSprints: async (projectId: string) => {
    set({ isLoading: true });
    try {
      const sprints = await db.getSprints(projectId);
      set({ sprints, isLoading: false });
    } catch (error) {
      console.error('Failed to fetch sprints:', error);
      set({ isLoading: false });
    }
  },

  createSprint: async (sprint: Partial<Sprint>) => {
    try {
      const created = await db.createSprint(sprint);
      set((state) => ({ sprints: [...state.sprints, created] }));
      return created;
    } catch (error) {
      console.error('Failed to create sprint:', error);
      throw error;
    }
  },

  updateSprint: async (id: string, updates: Partial<Sprint>) => {
    try {
      const updated = await db.updateSprint(id, updates);
      set((state) => ({
        sprints: state.sprints.map((sprint) => (sprint.id === id ? { ...sprint, ...updated } : sprint)),
      }));
    } catch (error) {
      console.error('Failed to update sprint:', error);
      throw error;
    }
  },

  deleteSprint: async (id: string) => {
    try {
      await db.deleteSprint(id);
      set((state) => ({
        sprints: state.sprints.filter((sprint) => sprint.id !== id),
      }));
    } catch (error) {
      console.error('Failed to delete sprint:', error);
      throw error;
    }
  },

  // Requirement Actions
  fetchRequirements: async (projectId: string, filters?: any) => {
    set({ isLoading: true });
    try {
      const requirements = await db.getRequirements(projectId, filters);
      const parsed = requirements.map((r: any) => ({
        ...r,
        tags: r.tags ? JSON.parse(r.tags) : [],
        metadata: r.metadata ? JSON.parse(r.metadata) : null,
      }));
      set({ requirements: parsed, isLoading: false });
    } catch (error) {
      console.error('Failed to fetch requirements:', error);
      set({ isLoading: false });
    }
  },

  createRequirement: async (requirement: Partial<Requirement>) => {
    try {
      const created = await db.createRequirement(requirement);
      const parsed = {
        ...created,
        tags: created.tags ? JSON.parse(created.tags) : [],
        metadata: created.metadata ? JSON.parse(created.metadata) : null,
      };
      set((state) => ({ requirements: [...state.requirements, parsed] }));
      return parsed;
    } catch (error) {
      console.error('Failed to create requirement:', error);
      throw error;
    }
  },

  updateRequirement: async (id: string, updates: Partial<Requirement>) => {
    try {
      const updated = await db.updateRequirement(id, updates);
      const parsed = {
        ...updated,
        tags: updated.tags ? JSON.parse(updated.tags) : [],
        metadata: updated.metadata ? JSON.parse(updated.metadata) : null,
      };
      set((state) => ({
        requirements: state.requirements.map((req) => (req.id === id ? { ...req, ...parsed } : req)),
      }));
    } catch (error) {
      console.error('Failed to update requirement:', error);
      throw error;
    }
  },

  deleteRequirement: async (id: string) => {
    try {
      await db.deleteRequirement(id);
      set((state) => ({
        requirements: state.requirements.filter((req) => req.id !== id),
      }));
    } catch (error) {
      console.error('Failed to delete requirement:', error);
      throw error;
    }
  },

  bulkCreateRequirements: async (projectId: string, requirements: Partial<Requirement>[]) => {
    try {
      const created = await db.bulkCreateRequirements(projectId, requirements);
      const parsed = created.map((r: any) => ({
        ...r,
        tags: r.tags ? JSON.parse(r.tags) : [],
        metadata: r.metadata ? JSON.parse(r.metadata) : null,
      }));
      set((state) => ({ requirements: [...state.requirements, ...parsed] }));
    } catch (error) {
      console.error('Failed to bulk create requirements:', error);
      throw error;
    }
  },
}));
