import { createBrowserRouter, Navigate } from 'react-router';
import HomePage from './pages/HomePage';
import { ProjectsDashboard } from './pages/ProjectsDashboard';
import TeamManagement from './pages/TeamManagement';
import ProjectsListPage from './pages/ProjectsListPage';
import ProjectDetailPage from './pages/ProjectDetailPage';
import ComprehensiveRequirementsPage from './pages/ComprehensiveRequirementsPage';
import { ProtectedRoute } from './components/ProtectedRoute';
import Login from './pages/Login';
import Register from './pages/Register';
import Unauthorized from './pages/Unauthorized';
import ArchitecturePage from './pages/ArchitecturePage';
import ArchitectureGeneratePage from './pages/ArchitectureGeneratePage';
import DeveloperDashboard from './pages/DeveloperDashboard';
import ManagerApproval from './pages/ManagerApproval';
import { EstimationWizard } from './pages/EstimationWizard';
import { MethodSelection } from './pages/steps/MethodSelection';
import { ProjectSetup } from './pages/steps/ProjectSetup';
import { ScopeDefinition } from './pages/steps/ScopeDefinition';
import { MethodDetails } from './pages/steps/MethodDetails';
import { RiskAssessment } from './pages/steps/RiskAssessment';
import { ReviewCalculate } from './pages/steps/ReviewCalculate';
import { GenerateDeliverables } from './pages/steps/GenerateDeliverables';
import AdminMetaModelPage from './pages/AdminMetaModelPage';
import CreateArtifactTypePage from './pages/CreateArtifactTypePage';
import BusinessRequirementsWizard from './pages/BusinessRequirementsWizard';
import RequirementsCaptureBoard from './pages/RequirementsCaptureBoard';
import CreateRequirement from './pages/CreateRequirement';
import CreateProject from './pages/CreateProject';
import RoadmapPage from './pages/RoadmapPage';
import KnowledgeHubPage from './pages/KnowledgeHubPage';

export const router = createBrowserRouter([
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/register',
    element: <Register />,
  },
  {
    path: '/unauthorized',
    element: <Unauthorized />,
  },
  {
    path: '/',
    element: (
      <ProtectedRoute>
        <Navigate to="/projects/list" replace />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/list',
    element: (
      <ProtectedRoute>
        <ProjectsListPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/create',
    element: (
      <ProtectedRoute>
        <CreateProject />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/:projectId',
    element: (
      <ProtectedRoute>
        <ProjectDetailPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/:projectId/requirements',
    element: (
      <ProtectedRoute>
        <RequirementsCaptureBoard />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/:projectId/requirements/add',
    element: (
      <ProtectedRoute>
        <CreateRequirement />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/:projectId/requirements/:id/edit',
    element: (
      <ProtectedRoute>
        <CreateRequirement />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/:projectId/requirements/comprehensive',
    element: (
      <ProtectedRoute>
        <ComprehensiveRequirementsPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/wizard',
    element: (
      <ProtectedRoute>
        <EstimationWizard />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <Navigate to="step/1" replace />,
      },
      {
        path: 'step/1',
        element: <MethodSelection />,
      },
      {
        path: 'step/2',
        element: <ProjectSetup />,
      },
      {
        path: 'step/3',
        element: <ScopeDefinition />,
      },
      {
        path: 'step/4',
        element: <MethodDetails />,
      },
      {
        path: 'step/5',
        element: <RiskAssessment />,
      },
      {
        path: 'step/6',
        element: <ReviewCalculate />,
      },
      {
        path: 'step/7',
        element: <GenerateDeliverables />,
      },
    ],
  },
  {
    path: '/teams',
    element: (
      <ProtectedRoute allowedRoles={['manager', 'admin']}>
        <TeamManagement />
      </ProtectedRoute>
    ),
  },
  {
    path: '/architecture',
    element: (
      <ProtectedRoute>
        <ArchitecturePage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/architecture/generate',
    element: (
      <ProtectedRoute>
        <ArchitectureGeneratePage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/developer/tasks',
    element: (
      <ProtectedRoute allowedRoles={['developer']}>
        <DeveloperDashboard />
      </ProtectedRoute>
    ),
  },
  {
    path: '/manager/approvals',
    element: (
      <ProtectedRoute allowedRoles={['manager', 'admin']}>
        <ManagerApproval />
      </ProtectedRoute>
    ),
  },
  {
    path: '/admin/metamodel',
    element: (
      <ProtectedRoute allowedRoles={['admin']}>
        <AdminMetaModelPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/admin/metamodel/create',
    element: (
      <ProtectedRoute allowedRoles={['admin']}>
        <CreateArtifactTypePage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/projects/:projectId/roadmap',
    element: (
      <ProtectedRoute>
        <RoadmapPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '/roadmap-items/:roadmapItemId/knowledge-hub',
    element: (
      <ProtectedRoute>
        <KnowledgeHubPage />
      </ProtectedRoute>
    ),
  },
  {
    path: '*',
    element: <Navigate to="/login" replace />,
  },
]);