/**
 * Database Abstraction Layer - Type Definitions
 */

// Auth Types
export interface AuthUser {
  id: string;
  email: string;
  fullName?: string;
  role?: string;
}

export interface AuthSession {
  access_token: string;
  user: AuthUser;
}

// Project Types
export interface Project {
  id: string;
  userId: string;
  name: string;
  description?: string;
  status: 'draft' | 'in_progress' | 'completed' | 'archived';
  estimationTechnique?: string;
  teamId?: string;
  createdAt: string;
  updatedAt: string;
}

// Roadmap Types
export interface Roadmap {
  id: string;
  projectId: string;
  year: number;
  type: 'product' | 'technology' | 'platform';
  createdBy: string;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}

export interface RoadmapItem {
  id: string;
  roadmapId: string;
  title: string;
  description?: string;
  startDate: string;
  endDate: string;
  status: 'planned' | 'in_progress' | 'completed' | 'on_hold' | 'cancelled';
  priority: 'low' | 'medium' | 'high' | 'critical';
  category?: string;
  assignedTo?: string;
  dependencies: string[];
  progress: number;
  createdAt: string;
  updatedAt: string;
}

// Knowledge Hub Types
export interface Document {
  id: string;
  roadmapItemId: string;
  name: string;
  type: 'BRD' | 'FRD' | 'TRD' | 'Other';
  version?: string;
  storagePath: string;
  fileSize: number;
  extractedText?: string;
  uploadedAt: string;
}

export interface Meeting {
  id: string;
  roadmapItemId: string;
  title: string;
  date: string;
  participants: string[];
  transcript?: string;
  notes?: string;
  keyDecisions: string[];
  createdAt: string;
}

export interface Email {
  id: string;
  roadmapItemId: string;
  subject: string;
  from: string;
  to: string[];
  body: string;
  date: string;
  createdAt: string;
}

export interface Chat {
  id: string;
  roadmapItemId: string;
  platform: 'Teams' | 'Slack' | 'Other';
  title?: string;
  channelName?: string;
  participants: string[];
  messages: string;
  date: string;
  createdAt: string;
}

export interface AIRequirement {
  id: string;
  roadmapItemId: string;
  requirement: string;
  source: string;
  sourceType: 'Document' | 'Meeting' | 'Email' | 'Chat';
  sourceId: string;
  category: 'Functional' | 'Non-Functional' | 'Security' | 'Performance' | 'Usability' | 'Scalability';
  priority: 'High' | 'Medium' | 'Low';
  confidence: number;
  extractedAt: string;
}

// Gap Analysis
export interface Gap {
  id: string;
  roadmapItemId: string;
  title: string;
  description: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed';
  sourceType: 'Document' | 'Meeting' | 'Email' | 'Chat' | 'AI' | 'Manual';
  sourceId?: string;
  suggestions: string[];
  resolution?: string;
  resolvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// Confusions
export interface Confusion {
  id: string;
  roadmapItemId: string;
  question: string;
  context: string;
  sources: Array<{ type: string; id: string; reference?: string }>;
  status: 'Open' | 'Clarified' | 'Resolved';
  clarification?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

// Suggestions
export interface Suggestion {
  id: string;
  roadmapItemId: string;
  title: string;
  description: string;
  type: 'Enhancement' | 'Alternative' | 'Best Practice' | 'Risk Mitigation';
  status: 'Pending' | 'Accepted' | 'Rejected' | 'Implemented';
  generatedBy: 'AI' | 'Manual';
  impact?: string;
  effort?: string;
  response?: string;
  createdAt: string;
  updatedAt: string;
}

// Security Requirements
export interface SecurityRequirement {
  id: string;
  roadmapItemId: string;
  title: string;
  description: string;
  category: 'Authentication' | 'Authorization' | 'Data Protection' | 'Network Security' | 'Compliance' | 'Other';
  level: 'Critical' | 'High' | 'Medium' | 'Low';
  standard?: string;
  controls: string[];
  testCriteria: string[];
  status: 'Draft' | 'Reviewed' | 'Approved';
  createdAt: string;
  updatedAt: string;
}

// Threat Analysis (STRIDE)
export interface Threat {
  id: string;
  roadmapItemId: string;
  threat: string;
  description: string;
  category: 'Spoofing' | 'Tampering' | 'Repudiation' | 'Information Disclosure' | 'Denial of Service' | 'Elevation of Privilege';
  level: 'Critical' | 'High' | 'Medium' | 'Low';
  likelihood: 'Very High' | 'High' | 'Medium' | 'Low' | 'Very Low';
  impact: string;
  mitigations: string[];
  status: 'Identified' | 'Mitigated' | 'Accepted' | 'Transferred';
  createdAt: string;
  updatedAt: string;
}

// Non-Functional Requirements
export interface NonFunctionalRequirement {
  id: string;
  roadmapItemId: string;
  category: 'Performance' | 'Scalability' | 'Reliability' | 'Availability' | 'Maintainability' | 'Usability' | 'Compliance';
  requirement: string;
  metric: string;
  target: string;
  measurement: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Draft' | 'Approved' | 'Met' | 'Not Met';
  createdAt: string;
  updatedAt: string;
}

// Alias for backward compatibility
export type NFR = NonFunctionalRequirement;

// Cloud Governance Requirements
export interface CloudGovernance {
  id: string;
  roadmapItemId: string;
  area: 'Cost Management' | 'Resource Governance' | 'Cloud Security' | 'Compliance' | 'Data Residency' | 'Disaster Recovery' | 'Networking';
  requirement: string;
  details: string;
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Draft' | 'Approved' | 'Implemented';
  createdAt: string;
  updatedAt: string;
}

// Formal Requirements (per roadmap item — manual + AI-imported)
export type FormalRequirementCategory = 'Functional' | 'Non-Functional' | 'Constraint' | 'Acceptance Criteria';

export type FunctionalType =
  | 'Feature' | 'Screen' | 'API' | 'Integration'
  | 'Bug Fix' | 'Data Migration' | 'Business Rule' | 'Other';

export type NFRType =
  | 'Performance' | 'Security' | 'Availability' | 'Scalability'
  | 'Concurrency' | 'Reliability' | 'Maintainability' | 'Usability'
  | 'Compliance' | 'Disaster Recovery' | 'Observability' | 'Other';

export type ConstraintType = 'Technical' | 'Budget' | 'Timeline' | 'Regulatory' | 'Other';

export interface FormalRequirement {
  id: string;
  roadmapItemId: string;
  projectId: string;

  // Auto-generated ID shown to user: REQ-F-001, REQ-NF-001, REQ-C-001
  requirementId: string;

  // Classification
  category: FormalRequirementCategory;
  functionalType?: FunctionalType;   // only when category = Functional
  nfrType?: NFRType;                 // only when category = Non-Functional
  constraintType?: ConstraintType;   // only when category = Constraint

  // Content
  title: string;
  description: string;

  // Priority + Status
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  status: 'Draft' | 'Under Review' | 'Approved' | 'Implemented' | 'Rejected';

  // User Story (Functional only)
  userStory?: { asA: string; iWant: string; soThat: string };

  // Acceptance Criteria
  acceptanceCriteria: string[];

  // NFR specifics
  metric?: string;
  target?: string;
  measurement?: string;

  // Source tracking
  source: 'Manual' | 'AI';
  aiSourceType?: 'Document' | 'Meeting' | 'Email' | 'Chat' | 'Gap' | 'Confusion' | 'Suggestion';
  aiSourceId?: string;
  aiConfidence?: number;

  // Metadata
  createdAt: string;
  updatedAt: string;
}
