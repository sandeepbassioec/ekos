/**
 * Database Abstraction Layer - Interface
 */

import type {
  Project,
  Roadmap,
  RoadmapItem,
  Document,
  Meeting,
  Email,
  Chat,
  AIRequirement,
  Gap,
  Confusion,
  Suggestion,
  SecurityRequirement,
  Threat,
  NFR,
  CloudGovernance,
  FormalRequirement,
  AuthUser,
  AuthSession,
} from './types';

export interface AuthProvider {
  signUp(email: string, password: string, fullName: string, role?: string): Promise<AuthSession>;
  signIn(email: string, password: string): Promise<AuthSession>;
  signOut(): Promise<void>;
  getSession(): Promise<AuthSession | null>;
  getUser(): Promise<AuthUser | null>;
}

export interface IDatabase {
  auth: AuthProvider;

  projects: {
    getAll(userId: string): Promise<Project[]>;
    getById(id: string, userId: string): Promise<Project>;
    create(project: Omit<Project, 'id' | 'createdAt' | 'updatedAt'>): Promise<Project>;
    update(id: string, userId: string, updates: Partial<Project>): Promise<Project>;
    delete(id: string, userId: string): Promise<void>;
  };

  roadmaps: {
    getByProject(projectId: string): Promise<Roadmap[]>;
    getById(id: string): Promise<Roadmap>;
    getByYearAndType(projectId: string, year: number, type: string): Promise<Roadmap | null>;
    create(roadmap: Omit<Roadmap, 'id' | 'createdAt' | 'updatedAt'>): Promise<Roadmap>;
    delete(id: string): Promise<void>;
  };

  roadmapItems: {
    getByRoadmap(roadmapId: string): Promise<RoadmapItem[]>;
    getById(id: string): Promise<RoadmapItem>;
    create(item: Omit<RoadmapItem, 'id' | 'createdAt' | 'updatedAt'>): Promise<RoadmapItem>;
    update(id: string, updates: Partial<RoadmapItem>): Promise<RoadmapItem>;
    delete(id: string): Promise<void>;
  };

  documents: {
    getByRoadmapItem(roadmapItemId: string): Promise<Document[]>;
    create(doc: Omit<Document, 'id' | 'uploadedAt'>, file: File): Promise<Document>;
    update(id: string, updates: Pick<Document, 'name' | 'type' | 'version'>): Promise<Document>;
    delete(id: string): Promise<void>;
    getDownloadUrl(id: string): Promise<string>;
  };

  meetings: {
    getByRoadmapItem(roadmapItemId: string): Promise<Meeting[]>;
    create(meeting: Omit<Meeting, 'id' | 'createdAt'>): Promise<Meeting>;
    update(id: string, updates: Partial<Meeting>): Promise<Meeting>;
    delete(id: string): Promise<void>;
  };

  emails: {
    getByRoadmapItem(roadmapItemId: string): Promise<Email[]>;
    create(email: Omit<Email, 'id' | 'createdAt'>): Promise<Email>;
    update(id: string, updates: Partial<Omit<Email, 'id' | 'roadmapItemId' | 'createdAt'>>): Promise<Email>;
    delete(id: string): Promise<void>;
  };

  chats: {
    getByRoadmapItem(roadmapItemId: string): Promise<Chat[]>;
    create(chat: Omit<Chat, 'id' | 'createdAt'>): Promise<Chat>;
    update(id: string, updates: Partial<Omit<Chat, 'id' | 'roadmapItemId' | 'createdAt'>>): Promise<Chat>;
    delete(id: string): Promise<void>;
  };

  aiRequirements: {
    getByRoadmapItem(roadmapItemId: string): Promise<AIRequirement[]>;
    create(data: Omit<AIRequirement, 'id' | 'extractedAt'>): Promise<AIRequirement>;
    delete(id: string): Promise<void>;
  };

  gaps: {
    getByRoadmapItem(roadmapItemId: string): Promise<Gap[]>;
    create(gap: Omit<Gap, 'id' | 'createdAt' | 'updatedAt'>): Promise<Gap>;
    update(id: string, updates: Partial<Gap>): Promise<Gap>;
    delete(id: string): Promise<void>;
  };

  confusions: {
    getByRoadmapItem(roadmapItemId: string): Promise<Confusion[]>;
    create(confusion: Omit<Confusion, 'id' | 'createdAt' | 'updatedAt'>): Promise<Confusion>;
    update(id: string, updates: Partial<Confusion>): Promise<Confusion>;
    delete(id: string): Promise<void>;
  };

  suggestions: {
    getByRoadmapItem(roadmapItemId: string): Promise<Suggestion[]>;
    create(suggestion: Omit<Suggestion, 'id' | 'createdAt' | 'updatedAt'>): Promise<Suggestion>;
    update(id: string, updates: Partial<Suggestion>): Promise<Suggestion>;
    delete(id: string): Promise<void>;
  };

  securityRequirements: {
    getByRoadmapItem(roadmapItemId: string): Promise<SecurityRequirement[]>;
    create(secReq: Omit<SecurityRequirement, 'id' | 'createdAt' | 'updatedAt'>): Promise<SecurityRequirement>;
    update(id: string, updates: Partial<SecurityRequirement>): Promise<SecurityRequirement>;
    delete(id: string): Promise<void>;
  };

  threats: {
    getByRoadmapItem(roadmapItemId: string): Promise<Threat[]>;
    create(threat: Omit<Threat, 'id' | 'createdAt' | 'updatedAt'>): Promise<Threat>;
    update(id: string, updates: Partial<Threat>): Promise<Threat>;
    delete(id: string): Promise<void>;
  };

  nfrs: {
    getByRoadmapItem(roadmapItemId: string): Promise<NFR[]>;
    create(nfr: Omit<NFR, 'id' | 'createdAt' | 'updatedAt'>): Promise<NFR>;
    update(id: string, updates: Partial<NFR>): Promise<NFR>;
    delete(id: string): Promise<void>;
  };

  cloudGovernance: {
    getByRoadmapItem(roadmapItemId: string): Promise<CloudGovernance[]>;
    create(cloudGov: Omit<CloudGovernance, 'id' | 'createdAt' | 'updatedAt'>): Promise<CloudGovernance>;
    update(id: string, updates: Partial<CloudGovernance>): Promise<CloudGovernance>;
    delete(id: string): Promise<void>;
  };

  formalRequirements: {
    getByRoadmapItem(roadmapItemId: string): Promise<FormalRequirement[]>;
    getByProject(projectId: string): Promise<FormalRequirement[]>;
    create(req: Omit<FormalRequirement, 'id' | 'createdAt' | 'updatedAt'>): Promise<FormalRequirement>;
    update(id: string, updates: Partial<FormalRequirement>): Promise<FormalRequirement>;
    delete(id: string): Promise<void>;
  };
}
